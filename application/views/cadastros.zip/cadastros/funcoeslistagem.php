<style>
    .tableFixHead          { overflow-y: auto; height: 450px; }
    .tableFixHead thead th { position: sticky; top: 0; }
    
    /* Just common table stuff. Really. */
    table  { border-collapse: collapse; width: 100%; }
    th, td { padding: 8px 16px; }
    th     { background:#eee; }
</style>

<br>
<section id="main-content">
    
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-6">
                <h3>Cadastros > Funções</h3>
            </div>
            <div class="col-md-6" style="text-align: right;">
                <a href="<?php echo base_url('cadastros/novaFuncao') ?>" class="btn btn-success" style='margin-top: 20px; border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white'>Nova Função</a>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <div class="row" style="margin-left: 0px; margin-right: 0px">
            <div class="col-md-12" style="background-color: white;">
                <br>
                
                <?php if($erro != null){ ?>
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="text-danger">Erro: A senha informada estava incorreta, por favor tente novamente!</h3>
                    </div>
                </div>
                <br>
                <?php } ?>
                
                <div class="tableFixHead">
				    <table id="myTableFunc" class="table table-hover table-bordered">
				        <thead>
				            <tr>
				                <th style="width: 80%">Funções</th>
				                <th style="width: 20%">Ação</th>
				            </tr>
				        </thead>
				        <tbody>
				            <?php foreach($funcoes as $funcao){ 
				                if($funcao['funcao_id'] != 1){
				                    if($this->session->userdata('c_a') != 1 && $funcao['funcao_ativo_id'] != 2){
				            ?>
				            <tr>
				                <td><?php echo mb_strtoupper($funcao['funcao_nome']) ?></td>
				                <td>
				                    <?php if($this->session->userdata('c_v') == 1){ ?>
			                        <a style="font-size: 12px" data-toggle="modal" data-target="#modalFuncao" data-funcao="<?php echo $funcao['funcao_id'] ?>" class="btn btn-primary btn-modal-toggle"><i class="fas fa-eye"></i></a>
			                        &nbsp&nbsp
			                        <?php } ?>
			                        <?php if($this->session->userdata('c_e') == 1){ ?>
			                        <a href="<?php echo base_url('cadastros/novaFuncao?edicao_id=') . $funcao['funcao_id'] ?>" class="btn btn-primary" style="font-size: 12px"><i class="fas fa-pencil-alt"></i></a>
			                        &nbsp&nbsp
			                        <?php } ?>
			                        <?php if($this->session->userdata('c_d') == 1){ ?>
			                        <a data-toggle="modal" data-target="#modalExcluir" class="btn btn-danger" style="font-size: 12px" onclick="setaExcluir('<?php echo $funcao['funcao_id'] ?>')"><i class="fas fa-trash"></i></i></a>
			                        <?php } ?>
			                    </td>
				            </tr>
				            <?php }else if($this->session->userdata('c_a') == 1){ ?>
				            <tr <?php if($funcao['funcao_ativo_id'] == 2){echo "style='background-color: #eaeaea'";} ?>>
				                <td><?php echo mb_strtoupper($funcao['funcao_nome']) ?></td>
				                <td>
				                    <?php if($this->session->userdata('c_v') == 1){ ?>
			                        <a style="font-size: 12px" data-toggle="modal" data-target="#modalFuncao" data-funcao="<?php echo $funcao['funcao_id'] ?>" class="btn btn-primary btn-modal-toggle"><i class="fas fa-eye"></i></a>
			                        &nbsp&nbsp
			                        <?php } ?>
			                        <?php if($this->session->userdata('c_e') == 1){ ?>
			                        <a href="<?php echo base_url('cadastros/novaFuncao?edicao_id=') . $funcao['funcao_id'] ?>" class="btn btn-primary" style="font-size: 12px"><i class="fas fa-pencil-alt"></i></a>
			                        &nbsp&nbsp
			                        <?php } ?>
			                        <?php if($this->session->userdata('c_d') == 1){ ?>
			                        <a data-toggle="modal" data-target="#modalExcluir" class="btn btn-danger" style="font-size: 12px" onclick="setaExcluir('<?php echo $funcao['funcao_id'] ?>')"><i class="fas fa-trash"></i></i></a>
			                        <?php } ?>
			                    </td>
				            </tr>
				            <?php } } } ?>
				        </tbody>
				        <tfoot>
				            <tr>
				                <th>Funções</th>
				                <th></th>
				            </tr>
				        </tfoot>
				    </table>
                </div>
                
                <br>
            </div>
        </div>
        
        <br><br>
        
    </section>
</section>

<div class="modal fade" id="modalExcluir" tabindex="-1" role="dialog" aria-labelledby="modalExcluirTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Mensagem do Sistema</h5>
            </div>
            <div class="modal-body">
                <h4>Deseja realmente excluir a função?</h4>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white; float: left" onclick="senha()">&nbsp&nbspSim&nbsp&nbsp</button>
                <button class="btn btn-danger" data-dismiss="modal">&nbsp&nbspNão&nbsp&nbsp</button>
                <br><br>
                <div class="row" id="formsenha" style="display: none">
                    <div class="col-md-12 text-center">
                        <form action="<?php echo base_url('cadastros/apagarFuncao') ?>" method="post">
                            <input type="hidden" name="funcao_id" id="funcao_id">
                            <label style="font-size: 16px">Confirme a senha</label><br>
                            <input class="form-control" type="password" name="senha" id="senha" placeholder="Digite a Senha" required style="width: 50%; margin-left: 25%"><br>
                            <button type="submit" class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">&nbsp&nbspConfirmar&nbsp&nbsp</button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<!-- ModalUsuario -->
<div class="modal fade" id="modalFuncao" tabindex="-1" role="dialog" aria-labelledby="modalFuncao" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="text-nome" name="text-nome">Funcao</h4>
                    </div>
                </div>
            </div>
            
            <div class="modal-body" style="background-color: #eaeaea; padding-bottom: 0px">
                <div class="row">
                    <div class="col-md-12">
                        <h3 id="text-permissao">
                            XX
                        </h3>
                    </div>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script>
    function setaExcluir(id){
        document.getElementById('funcao_id').value = id;
    }
    function senha(){
        document.getElementById('formsenha').style.display = "block";
    }
</script>

<script>
    $(document).ready(function(){
        
        $('.btn-modal-toggle').on('click', function(){
            $("#modalFuncao").modal('hide');
            var button = $(this);
            var recipient = button.data('funcao');
        
            var dados = {
                    'funcao_id': recipient
                };
            $.ajax({
                url : '<?php echo base_url('cadastros/getFuncaoById') ?>',
                type : "POST",
                dataType : "json",
                data : dados,
                success : function(response) {
                    res = response[0];
                    
                    $("#text-nome").html(res.funcao_nome);
                    var permissaoTexto = "<table class='table table-hover table-bordered'>"
                            +"<thead>"
    				            + "<tr>"
    				                + "<th style='width: 40%;'></th>"
    				                + "<th style='width: 15%; text-align: center; border-bottom: 1px solid black;'>Ver</th>"
    				                + "<th style='width: 15%; text-align: center; border-bottom: 1px solid black;'>Editar</th>"
    				                + "<th style='width: 15%; text-align: center; border-bottom: 1px solid black;'>Excluir</th>"
    				                + "<th style='width: 15%; text-align: center; border-bottom: 1px solid black;'>Ativar</th>"
    				            + "</tr>"
				            + "</thead>"
				            + "<tbody>";
				            
                    var permissao = res.funcao_permissao;
                    var permissaoSplit = permissao.split('|');
                
                    for(var i in permissaoSplit) {
                        permissaoTexto += "<tr>";
                        
                        var permissao = permissaoSplit[i];
                        var codPermissoes = permissao.split('-')[1];
                        
                        var nomeController = permissao.split('-')[0];
                        
                        permissaoTexto += "<th style='border-right: 1px solid black;'>" + nomeController + "</th>";
                        
                        for(var i=0; i<4; i++){
                            if(codPermissoes.charAt(i) == '0'){
                                permissaoTexto += "<th style='text-align: center; border: 1px solid black;'></th>";
                            }else { 
                                permissaoTexto += "<th style='text-align: center; border: 1px solid black;'><i class='fas fa-check'></i></th>";
                            } 
                        }
                        
                        permissaoTexto += "</tr>";
                    }
                    
                    permissaoTexto += "</tbody></table>";
                    
                    $("#text-permissao").html(permissaoTexto);
                    $("#modalFuncoes").modal('show');
                    
                },
                error : function(xhr, status, error) {
                    var err = eval("(" + xhr.responseText + ")");
                    alert(status + " " + error + " " + err);
                }
            });
        });
        
        $('.js-example-basic-multiple').select2({theme: "bootstrap"});
        $('#myTableFunc').DataTable( {
            "order": [[ 0, "asc" ]],
            "language": {
                "lengthMenu": "Mostrando _MENU_ registros por página",
                "zeroRecords": "Nada encontrado- refaça sua busca",
                "info": "Mostrando _PAGE_ de _PAGES_",
                "infoEmpty": "Sem registros disponíves",
                "infoFiltered": "(filtrado _MAX_ dos registros totais)",
                "sSearch":       "Procurar:",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Próximo",
                }
            },
            "columns": [
                {"Funções": "first", "orderable": true},
                {"Ação": "second", "orderable": false},
            ],
            initComplete: function () {
                this.api().columns([0]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
            }
        } );
    });
</script>