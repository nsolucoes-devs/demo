
<br>
<section id="main-content">
    
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-12">
                <h3>Cadastros > <?php if(isset($_GET['edicao_id'])){echo "Edição de Função";}else{echo "Cadastro de Função";} ?></h3>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <div class="row" style="margin-left: 0px; margin-right: 0px">
        <form action="<?php echo base_url('cadastros/insertFuncao') ?>" method="post">
            <input type="hidden" id="id" name="id" value=""/>
            
                <div class="col-md-12" style="background-color: white;">
                    <br><br>
                    
                    <div class="row">
                        <div class="col-md-8 form-group">
                            <label for="nome">Nome da Função: </label><br>
                            <input id="nome" name="nome" type="text" class="form-control disabled-field" placeholder="Ex.: Gerente" style="width:100%; float:right;" required> <br>
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="ativo">Ativo: </label><br>
                            <select class="js-example-basic-multiple disabled-field" style="width:100%; float:right;" name="ativo" id="ativo" required>
                                <?php foreach($ativos as $ativo){
                                    if(isset($_GET['edicao_id'])){
                                        if($this->session->userdata('c_a') == 1){
                                            echo '<option value="'.$ativo['ativo_id'].'">'.$ativo['ativo_tipo'].'</option>';
                                        }else{
                                            if($ativo['ativo_id'] == 2){
                                                echo '<option value="'.$ativo['ativo_id'].'">'.$ativo['ativo_tipo'].'</option>';
                                            }
                                        }
                                    }else if($ativo['ativo_id'] != 2){
                                        echo '<option value="'.$ativo['ativo_id'].'">'.$ativo['ativo_tipo'].'</option>';
                                    }
                                } ?>
                            </select>
                        </div>
                    </div>
                    <?php foreach($controladores as $permissao){ ?>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <label for="permissao-<?php echo $permissao['controlador_id'] ?>"><h4>Permissão - <?php echo $permissao['controlador_nome'] ?></h4></label>
                                <div style="width:100%; background-color:red;">
                                    <div class="col-md-3">
                                        <input id="<?php echo $permissao['controlador_id']?>-v" name="p-<?php echo $permissao['controlador_id']?>[]" type="checkbox" value="v">
                                        <label for="<?php echo $permissao['controlador_id']?>-v">Ver</label>
                                    </div>
                                    <div class="col-md-3">
                                        <input id="<?php echo $permissao['controlador_id']?>-e" name="p-<?php echo $permissao['controlador_id']?>[]" type="checkbox" value="e">
                                        <label for="<?php echo $permissao['controlador_id']?>-e">Editar</label>
                                    </div>
                                    <div class="col-md-3">
                                        <input id="<?php echo $permissao['controlador_id']?>-d" name="p-<?php echo $permissao['controlador_id']?>[]" type="checkbox" value="d">
                                        <label for="<?php echo $permissao['controlador_id']?>-d">Excluir</label>
                                    </div>
                                    <div class="col-md-3">
                                        <input id="<?php echo $permissao['controlador_id']?>-a" name="p-<?php echo $permissao['controlador_id']?>[]" type="checkbox" value="a">
                                        <label for="<?php echo $permissao['controlador_id']?>-a">Ativar</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <br><br>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <a id="check-all" href="#">Marcar tudo</a> | <a id="uncheck-all" href="#">Desmarcar tudo</a>
                        </div>
                    </div>
                    
                    <br>
                </div>
            </div>
            
            <br><br>
            
            <div class="row" style="margin-bottom: 40px">
                <div class="col-md-12 text-center">
                    <a href="<?php echo base_url('cadastros/funcoes') ?>" class="btn btn-danger">&nbsp&nbspCancelar&nbsp&nbsp</a>
                    &nbsp&nbsp&nbsp&nbsp
                    <button type="submit" class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">&nbsp&nbspSalvar e Voltar&nbsp&nbsp</button>
                    <!--&nbsp&nbsp&nbsp&nbsp
                    <a href="" class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">&nbsp&nbspSalvar e Continuar&nbsp&nbsp</a>-->
                </div>
            </div>
        </form>
        <br><br>
        
    </section>
</section>

<script>
    $(document).ready(function(){
            
        $('.js-example-basic-multiple').select2({theme: "bootstrap"});
        
        $("#check-all").on('click', function(){
            $("input[type=checkbox]").prop("checked", true);
        });
        
        $("#uncheck-all").on('click', function(){
            $("input[type=checkbox]").prop("checked", false);
        });
        
        function autoFillByID(id){
            var dados = {
                'funcao_id': id
            };
        
            $.ajax({
                url : '<?php echo base_url('cadastros/getFuncaoByID') ?>',
                type : 'POST',
                dataType : 'json',
                data : dados,
                success : function(response) {
                    res = response[0];
                    
                    $("#id").val(res.funcao_id);
                    $("#nome").val(res.funcao_nome);
                    $("#ativo").val(res.funcao_ativo_id);
                    
                    var permissao = res.funcao_permissao;
                    var permissaoSplitPipe = permissao.split('|');
                    
                    
                    for(i in permissaoSplitPipe){
                        var permissaoCodigo = permissaoSplitPipe[i].split('-')[1];
                        var controllerId = parseInt(i)+1;
                        if(permissaoCodigo.charAt(0) == '1'){
                            $("#" + controllerId + "-v").prop("checked", true);
                        }
                        if(permissaoCodigo.charAt(1) == '1'){
                            $("#" + controllerId + "-e").prop("checked", true);
                        }
                        if(permissaoCodigo.charAt(2) == '1'){
                            $("#" + controllerId + "-d").prop("checked", true);
                        }
                        if(permissaoCodigo.charAt(3) == '1'){
                            $("#" + controllerId + "-a").prop("checked", true);
                        }
                    }
                },
                error : function(xhr, status, error) {
                    alert(status + " " + error + " " + xhr);
                }
            });
        
            $('.disabled-field').removeAttr('disabled');
        }
        
        <?php 
            if(isset($_GET['edicao_id'])){
                $edicao_id = $_GET['edicao_id'];
        
                echo "
                    autoFillByID(". $edicao_id ."); 
                ";
        
            }
        ?>
        
    });
</script>