<style>
    .kv-avatar .krajee-default.file-preview-frame,.kv-avatar .krajee-default.file-preview-frame:hover {
        margin: 0;
        padding: 0;
        border: none;
        box-shadow: none;
        text-align: center;
    }
    .kv-avatar {
        display: inline-block;
    }
    .kv-avatar .file-input {
        display: table-cell;
        width: 213px;
    }
    .kv-reqd {
        color: red;
        font-family: monospace;
        font-weight: normal;
    }
    .xdiv{
        display: none;
    }
    .xlin{
        display: none;
    }
</style>

<br>
<section id="main-content" style="margin-bottom: 30px">
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-12">
                <h3>Cadastros > <?php if($edita != null){ echo "Edição de Fornecedor"; }else{ echo "Cadastro de Fornecedor"; } ?></h3>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <div class="row" style="margin-left: 0px; margin-right: 0px">
            
            <form id="fornecedorForm" action="<?php if($edita != null){ echo base_url('cadastros/updateFornecedor'); }else{ echo base_url('cadastros/insertFornecedor'); } ?>" method="post" enctype='multipart/form-data'>
                
                <div class="col-md-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist" style="background-color: #eaeaea">
                        <li class="nav-item">
                            <a class="nav-link" style="background-color: white; cursor: pointer; font-size: 18px" id="aDados" onclick="change(1)">Dados</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" style="cursor: pointer; font-size: 18px" id="aDoc" onclick="change(2)">Documentos</a>
                        </li>
                    </ul>
                    
                    <div class="row" id="divDados" style="display: block;">
                        <div class="col-md-12" style="background-color:white; border-radius: 5px">
                            <br><br>
                            
                            <div class="row">
                                <div class="col-md-12 form-group">
                                    <a style="background-color: #4ECDC4; border-color: #4ECDC4;" class="btn btn-primary" href="<?php echo base_url('cadastros/fornecedores') ?>"><i class="fas fa-backward"></i>&nbsp;Voltar</a>
                                </div>
                            </div>
                            
                            <br>
                            
                            <div class="row">
                                <div class="col-md-4 form-group">
                                    <label>CNPJ (Somente Números)</label><br>
                                    <input id="cnpj" name="cnpj" type="text" class="form-control" placeholder="000.000.000-00" required <?php if($edita != null){echo "value='".$edita['fornecedor_cnpj']."' disabled";} ?>>
                                        <input type="hidden" name="index" id="index" <?php if($edita != null){echo "value='".$edita['fornecedor_cnpj']."'";} ?>>
                                </div>
                                <div class="col-md-2 form-group">
                                    <a id="divbtn" onclick="cnpjSearch()" class="btn btn-primary" style="margin-top: 22px; background-color: #4ECDC4; border-color: #4ECDC4;"><i class="fa fa-search"></i></a>
                                    <label id="space">&nbsp;&nbsp;&nbsp;</label>
                                    <a href="<?php echo base_url('cadastros/novoFornecedor') ?>" class="btn btn-danger" style="margin-top: 22px"><i class="fas fa-sync-alt"></i></a>
                                </div>
                                <div class="col-md-6 form-group text-right">
                                    <label style="color: #c90000; margin-top: 20px">Campos marcados com ** NÃO são obrigatórios!</label>
                                </div>
                            </div>

                            <div class="row xdiv">
                                <div class="col-md-12 form-group">
                                    <label>Nome Fantasia</label><br>
                                    <input id="nome" name="nome" type="text" class="form-control x" placeholder="Nome Fantasia" disabled <?php if($edita != null){echo "value='" . $edita['fornecedor_nome'] . "'";} ?>>
                                </div>
                            </div>

                            <div class="row xdiv">
                                <div class="col-md-7 form-group">
                                    <label>Razão Social</label><br>
                                    <input id="razao" name="razao" type="text" class="form-control x" placeholder="Razão Social" disabled <?php if($edita != null){echo "value='" . $edita['fornecedor_razao'] . "'";} ?>>
                                </div>
                                <div class="col-md-5 form-group">
                                    <label>Ramo de Atividade</label><br>
                                    <input id="ramo" name="ramo" type="text" class="form-control x" placeholder="Ramo de Atividade" disabled <?php if($edita != null){echo "value='" . $edita['fornecedor_ramo'] . "'";} ?>>
                                </div>
                            </div>
                            
                            <div class="row xdiv">
                                <div class="col-md-8">
                                    <label>Nome do Representante</label><br>
                                    <input id="nome_r" name="nome_r" type="text" class="form-control x" placeholder="Nome do Representante" disabled <?php if($edita != null){echo "value='" . $edita['fornecedor_representante'] . "'";}?>>
                                </div>
                                <div class="col-md-4">
                                    <label>Telefone do Representante</label><br>
                                    <input id="tel_r" name="tel_r" type="text" class="form-control x" placeholder="(00) 00000-0000" disabled <?php if($edita != null){echo "value='" . $edita['fornecedor_tel_representante'] . "'";}?>>
                                </div>
                            </div>
                            
                            <hr class="xlin" style="height: 1px; background-color: #ccc; border: none;">
                            
                            <div class="row xdiv">
                                <div class="col-md-3 form-group">
                                    <label>CEP</label><br>
                                    <input id="cep" name="cep" type="text" class="form-control x" placeholder="00000-000" required disabled <?php if($edita != null){echo "value='".$edita['fornecedor_cep']."'";} ?>>
                                </div>
                                <div class="col-md-7 form-group">
                                    <label>Logradouro</label><br>
                                    <input id="endereco" name="endereco" type="text" class="form-control x" placeholder="Logradouro" required disabled <?php if($edita != null){echo "value='".$edita['fornecedor_endereco']."'";} ?>>
                                </div>
                                <div class="col-md-2 form-group">
                                    <label>Número</label><br>
                                    <input id="numero" name="numero" type="text" class="form-control x" placeholder="000" required disabled <?php if($edita != null){echo "value='".$edita['fornecedor_numero']."'";} ?>>
                                </div>
                            </div>
            
                            <div class="row xdiv">
                                <div class="col-md-3 form-group">
                                    <label>Bairro</label><br>
                                    <input id="bairro" name="bairro" type="text" class="form-control x" placeholder="Bairro" required disabled <?php if($edita != null){echo "value='".$edita['fornecedor_bairro']."'";} ?>>
                                </div>
                                <div class="col-md-3 form-group">
                                    <label>Complemento</label><label style="color: #c90000">&nbsp;&nbsp;**</label><br>
                                    <input id="complemento" name="complemento" type="text" class="form-control x" placeholder="Complemento" disabled <?php if($edita != null){echo "value='".$edita['fornecedor_complemento']."'";} ?>>
                                </div>
                                <div class="col-md-3 form-group">
                                    <label>Cidade</label><br>
                                    <input id="cidade" name="cidade" type="text" class="form-control x" placeholder="Cidade" required disabled <?php if($edita != null){echo "value='".$edita['fornecedor_cidade']."'";} ?>>
                                </div>
                                <div class="col-md-3 form-group">
                                    <label>Estado</label><br>
                                    <input id="estado" name="estado" type="text" class="form-control x" placeholder="Estado" required disabled <?php if($edita != null){echo "value='".$edita['fornecedor_estado']."'";} ?>>
                                </div>
                            </div>
                            
                            <hr class="xlin" style="height: 1px; background-color: #ccc; border: none;">
                            
                            <div class="row xdiv">
                                <div class="col-md-12 form-group">
                                    <label>E-mail</label><br>
                                    <input id="email" name="email" type="text" class="form-control x" placeholder="email@mail.com" required disabled <?php if($edita != null){echo "value='".$edita['fornecedor_email']."'";} ?>>
                                </div>
                            </div>
                            <div class="row xdiv">
                                <div class="col-md-4 form-group">
                                    <label>Telefone Fixo</label><br>
                                    <input id="tel" name="tel" type="text" class="form-control x" placeholder="(00) 0000-0000" required disabled <?php if($edita != null){echo "value='".$edita['fornecedor_fixo']."'";} ?>>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label>Celular</label><br>
                                    <input id="cel" name="cel" type="text" class="form-control x" placeholder="(00) 00000-0000" required disabled <?php if($edita != null){echo "value='".$edita['fornecedor_cel1']."'";} ?>>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label>Ativo</label><br>
                                    <select class="js-example-basic-multiple x" style="width:100%;" name="ativo" id="ativo" required disabled>
                                        <?php foreach($ativos as $ativo){
                                            if($edita != null){
                                                if($ativo['ativo_id'] == $edita['fornecedor_ativo_id']){$sel = " selected ";}else{$sel = "";}
                                                if($this->session->userdata('y_a') == 1){
                                                    echo '<option value="'.$ativo['ativo_id'].'" '.$sel.'>'.$ativo['ativo_tipo'].'</option>';
                                                }else if($edita['fornecedor_ativo_id'] == 2){
                                                    if($ativo['ativo_id'] == 2){
                                                        echo '<option value="'.$ativo['ativo_id'].'" '.$sel.'>'.$ativo['ativo_tipo'].'</option>';
                                                    }
                                                }else{
                                                    if($ativo['ativo_id'] != 2){
                                                        echo '<option value="'.$ativo['ativo_id'].'" '.$sel.'>'.$ativo['ativo_tipo'].'</option>';
                                                    }
                                                }
                                            }else if($ativo['ativo_id'] != 2){
                                                echo '<option value="'.$ativo['ativo_id'].'" '.$sel.'>'.$ativo['ativo_tipo'].'</option>';
                                            }
                                        } ?>
                                    </select>
                                </div>
                            </div>
                            
                            <br><br>
                            
                        </div>
                    </div>
                    
                    <div class="row" id="divDocs" style="display: none;">
                        
                        <div class="col-md-12" style="background-color:white; border-radius: 5px">
                            <br><br>
                            
                            <!--<div class="row xdiv">
                                <div class="col-md-4">
                                    <div style="max-width: 200px; margin: auto">
                                        <h3>RG</h3>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div style="max-width: 200px; margin: auto">
                                        <h3>CPF</h3>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div style="max-width: 200px; margin: auto">
                                        <h3>Habilitação</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="row xdiv">
                                <div class="col-md-4 text-center">
                                    <div style="max-width: 200px; margin: auto">
                                        <div style="position: relative;">
                                            <img src="<?php
                                            if($edita != null){
                                                echo base_url('uploads/' . $edita['fornecedor_cnpj'] . '_rg.png');
                                            }else{
                                                echo base_url('resources/imgs/imgplaceholder.png');
                                            }
                                            ?>" id="rg-preview" class="img-thumbnail" style="max-width:200px; height:auto;"/>
                                        </div>
                                        <div style="position: absolute; top: 0;">
                                            <div class="input-group my-3">
                                                <input type="text" class="form-control" placeholder="Selecione uma imagem" id="rg-file" disabled style="display: none;" <?php if($edita != null){ echo 'value="'.$edita['fornecedor_cnpj'] . '_rg.png"'; } ?>/>
                                                <div class="input-group-append">
                                                    <input id="rg-doc" type="file" name="rg-doc" form="fornecedorForm" class="file" accept="image/png" style="display:none;" required <?php if($edita != null){ echo "disabled" ; } ?>/>
                                                    <button id="rg-search" type="button" class="browse btn btn-primary">Buscar...</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 text-center">
                                    <div style="max-width: 200px; margin: auto">
                                        <div style="position: relative;">
                                            <img src="<?php
                                            if($edita != null){
                                                echo base_url('uploads/' . $edita['fornecedor_cnpj'] . '_cpf.png');
                                            }else{
                                                echo base_url('resources/imgs/imgplaceholder.png');
                                            }
                                            ?>" id="cpf-preview" class="img-thumbnail" style="max-width:200px; height:auto;"/>
                                        </div>
                                        <div style="position: absolute; top: 0;">
                                            <div class="input-group my-3">
                                                <input type="text" class="form-control" placeholder="Selecione uma imagem" id="cpf-file" disabled style="display: none;" <?php if($edita != null){ echo 'value="'.$edita['fornecedor_cnpj'] . '_cpf.png"'; } ?>/>
                                                <div class="input-group-append">
                                                    <input id="cpf-doc" type="file" name="cpf-doc" form="fornecedorForm" class="file" accept="image/png" style="display:none;" required <?php if($edita != null){ echo "disabled" ; } ?>/>
                                                    <button id="cpf-search" type="button" class="browse btn btn-primary">Buscar...</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 text-center">
                                    <div style="max-width: 200px; margin: auto">
                                        <div style="position: relative;">
                                            <img src="<?php
                                            if($edita != null){
                                                echo base_url('uploads/' . $edita['fornecedor_cnpj'] . '_hab.png');
                                            }else{
                                                echo base_url('resources/imgs/imgplaceholder.png');
                                            }
                                            ?>" id="hab-preview" class="img-thumbnail" style="max-width:200px; height:auto;"/>
                                        </div>
                                        <div style="position: absolute; top: 0;">
                                            <div class="input-group my-3">
                                                <input type="text" class="form-control" placeholder="Selecione uma imagem" id="hab-file" disabled style="display: none;" <?php if($edita != null){ echo 'value="'.$edita['fornecedor_cnpj'] . '_hab.png"'; } ?>/>
                                                <div class="input-group-append">
                                                    <input id="hab-doc" type="file" name="hab-doc" form="fornecedorForm" class="file" accept="image/png" style="display:none;" required <?php if($edita != null){ echo "disabled" ; } ?>/>
                                                    <button id="hab-search" type="button" class="browse btn btn-primary">Buscar...</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>-->
                            
                            <div class="row xdiv" style="margin-top: 100px">
                                <div class="col-md-12 text-center">
                                    <a href="<?php echo base_url('fornecedor/listagem') ?>" class="btn btn-danger">&nbsp&nbspCancelar&nbsp&nbsp</a>
                                    &nbsp&nbsp&nbsp&nbsp
                                    <button type="submit" id="btn-save" class="btn btn-primary" style="background-color: #4ECDC4; border-color: #4ECDC4;">&nbsp&nbspSalvar&nbsp&nbsp</button>
                                </div>
                            </div>
                            
                            <br><br>
                        </div>
                        
                    </div>
                    
                </div>

            </form>
        </div>
        <br><br>
    </section>
</section>

<script>
    $(document).ready(function(){
        
        var SPMaskBehavior = function (val) {
            return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
        },
        spOptions = {
            onKeyPress: function(val, e, field, options) {
                field.mask(SPMaskBehavior.apply({}, arguments), options);
            }
        };
        
        $('.js-example-basic-multiple').select2({theme: "bootstrap"});
        $('#cnpj').mask('00.000.000/0000-00', {'translation': {0: {pattern: /[0-9*]/}}});
        $('#tel').mask(SPMaskBehavior, spOptions);
        $('#cel').mask(SPMaskBehavior, spOptions);
        $('#tel_r').mask(SPMaskBehavior, spOptions);
        $('#cep').mask('00000-000', {reverse: true}, {'translation': {0: {pattern: /[0-9*]/}}});
    });
</script>

<script>
    $(document).on("click", ".browse", function() {
        var id = this.id;
        id = id.replaceAll("-search", "");
        var file = $(this).parents().find("#" + id + "-doc");
        file.prop("disabled", false);
        file.trigger("click");
    });
    
    $('input[type="file"]').change(function(e) {
        var fileID = this.id;
        fileID = fileID.replaceAll("-doc", "");
        var fileName = e.target.files[0].name;
        $("#" + fileID + "-file").val(fileName);
        
        var reader = new FileReader();
        reader.onload = function(e) {
             document.getElementById(fileID + "-preview").src = e.target.result;
        };
        reader.readAsDataURL(this.files[0]);
    });
</script>

<script>
     function change(value){
        if(value == 1){
            document.getElementById('aDados').style.backgroundColor = "white";
            document.getElementById('aDoc').style.backgroundColor = "#eaeaea";
            
            document.getElementById('divDados').style.display = "block";
            document.getElementById('divDocs').style.display = "none";
        }else{
            document.getElementById('aDados').style.backgroundColor = "#eaeaea";
            document.getElementById('aDoc').style.backgroundColor = "white";
            
            document.getElementById('divDados').style.display = "none";
            document.getElementById('divDocs').style.display = "block";
        }
    }
</script>

<script>
    $("#cep").keyup(function(){
        
        if($("#cep").val().length == 9){
			var cep = this.value.replace(/[^0-9]/, "");
			var url = "https://viacep.com.br/ws/"+cep+"/json/";

			if(cep.length != 8){
				return false;
			}

			$.getJSON(url, function(dadosRetorno){
				try{
					$("#endereco").val(dadosRetorno.logradouro);
					$("#bairro").val(dadosRetorno.bairro);
					$("#cidade").val(dadosRetorno.localidade);
					$("#estado").val(dadosRetorno.uf);
				}catch(ex){
				    alert("Erro na captura dos dados a partir do CEP: " + ex);
				}
			});
        }
        
	});
</script>

<script>
    function cnpjSearch(){
        
        var cnpj = $('#cnpj').val().replace(/[^\d]+/g,'');
        var tam = cnpj.length;
        var dados = {'cnpj': cnpj};
        
        if(tam == 14){
            $('.x').prop('disabled', false);

            $.ajax({
                url : '<?php echo base_url('cadastros/verificaFornecedor') ?>',
                type : "POST",
                dataType : "json",
                data : dados,
                success : function(res) {
                    if(res != null){
                        $('#fornecedorForm').attr('action', '<?php echo base_url('cadastros/updateFornecedor') ?>');
                        $('#cnpj').prop('disabled', true);
                        $('.xdiv').css('display', 'block');
                        $('.xlin').css('display', 'block');
                        $('#divbtn').css('display', 'none');
                        $('#space').css('display', 'none');

                        $('#index').val(res.fornecedor_cnpj);
                        $('#nome').val(res.fornecedor_nome);
                        $('#razao').val(res.fornecedor_razao);
                        $('#cep').val(res.fornecedor_cep);
                        $('#numero').val(res.fornecedor_numero);
                        $('#complemento').val(res.fornecedor_complemento);
                        $('#endereco').val(res.fornecedor_endereco);
                        $('#bairro').val(res.fornecedor_bairro);
                        $('#cidade').val(res.fornecedor_cidade);
                        $('#estado').val(res.fornecedor_estado);
                        $('#tel').val(res.fornecedor_fixo);
                        $('#cel').val(res.fornecedor_cel1);
                        $('#ativo').val(res.fornecedor_ativo_id);
                        $('#email').val(res.fornecedor_email);
                        $('#ramo').val(res.fornecedor_ramo);
                        $('#tel_r').val(res.fornecedor_tel_representante);
                        $('#nome_r').val(res.fornecedor_representante);
                        
                        var rg = "<?php echo base_url('uploads/')?>" + res.fornecedor_cnpj + "_rg.png";
                        var cpf = "<?php echo base_url('uploads/')?>" + res.fornecedor_cnpj + "_cpf.png";
                        var hab = "<?php echo base_url('uploads/')?>" + res.fornecedor_cnpj + "_hab.png";
                        
                        $('#rg-preview').attr('src', rg);
                        $('#cpf-preview').attr('src', cpf);
                        $('#hab-preview').attr('src', hab);
                        
                        $('#rg-file').val(res.fornecedor_cnpj + "_rg.png");
                        $('#cpf-file').val(res.fornecedor_cnpj + "_cpf.png");
                        $('#hab-file').val(res.fornecedor_cnpj + "_hab.png");

                        $('#rg-doc').prop('disabled', true);
                        $('#cpf-doc').prop('disabled', true);
                        $('#hab-doc').prop('disabled', true);
                    }else{
                        $('.xdiv').css('display', 'block');
                        $('.xlin').css('display', 'block');
                    }
                },
                error : function(xhr, status, error) {
                    alert('erro');
                }
            });
        }else{
            $('.x').prop('disabled', true);
            alert('Digite um CNPJ válido!');
        }
    }
    
    <?php if($edita != null){ ?>
        var cnpj = $('#cnpj').val().replace(/[^\d]+/g,'');
        var tam = cnpj.length;
        var dados = {'cnpj': cnpj};
        
        if(tam == 14){
            $('.x').prop('disabled', false);

            $.ajax({
                url : '<?php echo base_url('cadastros/verificaFornecedor') ?>',
                type : "POST",
                dataType : "json",
                data : dados,
                success : function(res) {
                    if(res != null){
                        $('#cnpj').prop('disabled', true);
                        $('.xdiv').css('display', 'block');
                        $('.xlin').css('display', 'block');
                        $('#divbtn').css('display', 'none');
                        $('#space').css('display', 'none');
                    }else{
                        $('.xdiv').css('display', 'block');
                        $('.xlin').css('display', 'block');
                    }
                },
                error : function(xhr, status, error) {
                    alert('erro');
                }
            });
        }else{
            $('.x').prop('disabled', true);
            alert('Digite um CNPJ válido!');
        }
    <?php } ?>
</script>
