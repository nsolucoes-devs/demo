<style>
    .tableFixHead          { overflow-y: auto; height: 600px; }
    .tableFixHead thead th { position: sticky; top: 0; }
    
    /* Just common table stuff. Really. */
    table  { border-collapse: collapse; width: 100%; }
    th, td { padding: 8px 16px; }
    th     { background:#eee; }
    
    .blue_btn{
        border: 1px solid #4ECDC4;
        background-color: #4ECDC4;
        padding: 10px 15px;
        color: white;
    }
    .red_btn{
        border: 1px solid #FF1111;
        background-color: #FF1111;
        padding: 10px 15px;
        color: white;
    }
</style>

<br>
<section id="main-content">
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-6">
                <h3>Clientes > Listagem</h3>
            </div>
            <div class="col-md-6" style="text-align: right;">
                <a href="<?php echo base_url('cliente/cadastro'); ?>" class="btn btn-primary" style="margin-top: 20px; border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">Novo Cliente</a>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <div class="row" style="margin-left: 0px; margin-right: 0px">
            <div class="col-md-12" style="background-color: white;">
                <br>
                
                <?php if($erro != null){ ?>
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="text-danger">Erro: A senha informada estava incorreta, por favor tente novamente!</h3>
                    </div>
                </div>
                <br>
                <?php } ?>
                
                <div class="tableFixHead">
                    <table id="myTableCliente" class="table table-hover table-bordered">
                          <thead>
                                <tr>
                                    <th>CPF</th>
                                    <th>Nome</th>
                                    <th>Cidade</th>
                                    <th>Estado</th>
                                    <th style="width: 180px">Ação</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                foreach($clientes as $cliente){
                                    if($this->session->userdata('y_a') != 1 && $cliente['cliente_ativo_id'] != 2){    
                                ?>
                                 <tr>
                                    <td>
                                        <?php 
                                        $tam = strlen($cliente['cliente_cpfcnpj']);
                                        if($tam == 11){
                                            $cpfcnpj = substr($cliente['cliente_cpfcnpj'], 0, 3).".".substr($cliente['cliente_cpfcnpj'], 3, 3).".".substr($cliente['cliente_cpfcnpj'], 6, 3)."-".substr($cliente['cliente_cpfcnpj'], 9); 
                                        }else{
                                            $cpfcnpj = substr($cliente['cliente_cpfcnpj'], 0, 2).".".substr($cliente['cliente_cpfcnpj'], 2, 3).".".substr($cliente['cliente_cpfcnpj'], 5, 3)."/".substr($cliente['cliente_cpfcnpj'], 8, 4)."-".substr($cliente['cliente_cpfcnpj'], 12);
                                        }
                                        echo $cpfcnpj;
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $tam = strlen($cliente['cliente_cpfcnpj']);
                                        if($tam == 11){
                                            $nome = $cliente['cliente_nome'];
                                        }else{
                                            $nome = $cliente['cliente_fantasia'];
                                        }
                                        echo mb_strtoupper($nome);
                                        ?>
                                    </td>
                                    <td><?php echo $cliente['cliente_cidade'] ?></td>
                                    <td><?php echo $cliente['cliente_estado'] ?></td>
                                    <td>
                                        <?php if($this->session->userdata('y_v') == 1){ ?>
                                        <a style="font-size: 12px" href="<?php echo base_url('cliente/verCliente/').$cliente['cliente_cpfcnpj']?>" class="btn btn-primary btn-modal-toggle"><i class="fas fa-eye"></i></a>
                                        &nbsp&nbsp
                                        <?php } ?>
                                        <?php if($this->session->userdata('y_e') == 1){ ?>
                                        <a style="font-size: 12px" href="<?php echo base_url('cliente/telaEdita/') . $cliente['cliente_cpfcnpj']; ?>" class="btn btn-primary" ><i class="fas fa-pencil-alt"></i></a>
                                        &nbsp&nbsp
                                        <?php } ?>
                                        <?php if($this->session->userdata('y_d') == 1){ ?>
                                        <a data-toggle="modal" data-target="#modalExcluir" style="font-size: 12px" class="btn btn-danger" onclick="setaExcluir('<?php echo $cliente['cliente_cpfcnpj'] ?>')"><i class="fas fa-trash"></i></a>
                                        <?php } ?>
                                    </td>
                                </tr>
                                <?php }else if($this->session->userdata('y_a') == 1){ ?>
				                <tr <?php if($cliente['cliente_ativo_id'] == 2){echo "style='background-color: #eaeaea'";} ?>>
    				                <td>
                                        <?php 
                                        $tam = strlen($cliente['cliente_cpfcnpj']);
                                        if($tam == 11){
                                            $cpfcnpj = substr($cliente['cliente_cpfcnpj'], 0, 3).".".substr($cliente['cliente_cpfcnpj'], 3, 3).".".substr($cliente['cliente_cpfcnpj'], 6, 3)."-".substr($cliente['cliente_cpfcnpj'], 9); 
                                        }else{
                                            $cpfcnpj = substr($cliente['cliente_cpfcnpj'], 0, 2).".".substr($cliente['cliente_cpfcnpj'], 2, 3).".".substr($cliente['cliente_cpfcnpj'], 5, 3)."/".substr($cliente['cliente_cpfcnpj'], 8, 4)."-".substr($cliente['cliente_cpfcnpj'], 12);
                                        }
                                        echo $cpfcnpj;
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $tam = strlen($cliente['cliente_cpfcnpj']);
                                        if($tam == 11){
                                            $nome = $cliente['cliente_nome'];
                                        }else{
                                            $nome = $cliente['cliente_fantasia'];
                                        }
                                        echo mb_strtoupper($nome);
                                        ?>
                                    </td>
                                    <td><?php echo $cliente['cliente_cidade'] ?></td>
                                    <td><?php echo $cliente['cliente_estado'] ?></td>
                                    <td>
                                        <?php if($this->session->userdata('y_v') == 1){ ?>
                                        <a style="font-size: 12px" href="<?php echo base_url('cliente/verCliente/').$cliente['cliente_cpfcnpj']?>" class="btn btn-primary btn-modal-toggle"><i class="fas fa-eye"></i></a>
                                        &nbsp&nbsp
                                        <?php } ?>
                                        <?php if($this->session->userdata('y_e') == 1){ ?>
                                        <a style="font-size: 12px" href="<?php echo base_url('cliente/telaEdita/') . $cliente['cliente_cpfcnpj']; ?>" class="btn btn-primary" ><i class="fas fa-pencil-alt"></i></a>
                                        &nbsp&nbsp
                                        <?php } ?>
                                        <?php if($this->session->userdata('y_d') == 1){ ?>
                                        <a data-toggle="modal" data-target="#modalExcluir" style="font-size: 12px" class="btn btn-danger" onclick="setaExcluir('<?php echo $cliente['cliente_cpfcnpj'] ?>')"><i class="fas fa-trash"></i></a>
                                        <?php } ?>
                                    </td>
                                </tr>
                                <?php } } ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>CPF</th>
                                    <th>Nome</th>
                                    <th>Cidade</th>
                                    <th>Estado</th>
                                    <th></th>
                                </tr>
                            </tfoot>
                    </table>
                </div>
                
                <br> 
            </div>
        </div>
        <br><br>
    </section>
</section>

<div class="modal fade" id="modalExcluir" tabindex="-1" role="dialog" aria-labelledby="modalExcluirTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Mensagem do Sistema</h5>
            </div>
            <div class="modal-body">
                <h4>Deseja realmente excluir o cliente?</h4>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white; float: left" onclick="senha()">&nbsp&nbspSim&nbsp&nbsp</button>
                <button class="btn btn-danger" data-dismiss="modal">&nbsp&nbspNão&nbsp&nbsp</button>
                <br><br>
                <div class="row" id="formsenha" style="display: none">
                    <div class="col-md-12 text-center">
                        <form action="<?php echo base_url('cliente/deleteCliente') ?>" method="post">
                            <input type="hidden" name="cpfcli" id="cpfcli">
                            <label style="font-size: 16px">Confirme a senha</label><br>
                            <input class="form-control" type="password" name="senha" id="senha" placeholder="Digite a Senha" required style="width: 50%; margin-left: 25%"><br>
                            <button type="submit" class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">&nbsp&nbspConfirmar&nbsp&nbsp</button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<!-- ModalCliente -->
<div class="modal fade" id="modalCliente" tabindex="-1" role="dialog" aria-labelledby="modalCliente" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-11">
                        <h5 class="modal-title">Dados do Cliente</h5>
                    </div>
                    <div class="col-md-1">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                </div>
            </div>
            
            <div class="modal-body" style="background-color: #eaeaea; padding-bottom: 0px">
                <ul class="nav nav-tabs" id="myTab" role="tablist" style="background-color: #eaeaea">
                    <li class="nav-item">
                        <a class="nav-link" style="background-color: white; cursor: pointer" id="aDados" onclick="change(1)">Dados</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="cursor: pointer" id="aEnd" onclick="change(2)">Endereço</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="cursor: pointer" id="aDoc" onclick="change(3)">Documentos</a>
                    </li>
                </ul>
                <div class="row" id="divDados" style="display: block;">
                    <div class="col-md-12" style="background-color: white">
                        <br>
                        
                        <div class="row form-group">
                            <div class="col-md-12">
                                <label>Nome: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-nome" name="text-nome">Nome Completo</label>
                            </div>
                        </div>
                        
                        <div class="row form-group">
                            <div class="col-md-6">
                                <label>CPF: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-cpf">XXX.XXX.XXX-XX</label>
                            </div>
                            <div class="col-md-6">
                                <label>RG: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-rg">XX XXX XXX-X</label>
                            </div>
                        </div>
                        
                        <div class="row form-group">
                            <div class="col-md-12">
                                <label>Telefone Fixo: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-fixo">(XX) XXXX-XXXX</label>
                            </div>
                        </div>
                        
                        <div class="row form-group">
                            <div class="col-md-6">
                                <label>Celular 1: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-cel1">(XX) XXXXX-XXXX</label>
                            </div>
                            <div class="col-md-6">
                                <label>Celular 2: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-cel2">(XX) XXXXX-XXXX</label>
                            </div>
                        </div>
                        
                        <br>
                    </div>
                </div>
                <div class="row" id="divEnd" style="display: none">
                    <div class="col-md-12" style="background-color: white">
                        <br>

                        <div class="row form-group">
                            <div class="col-md-12">
                                <label>Endereco: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-endereco">Rua X, nº X</label>
                            </div>
                        </div>
                        
                        <div class="row form-group">
                            <div class="col-md-4">
                                <label>Bairro: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-bairro">X</label>
                            </div>
                            <div class="col-md-4">
                                <label>Cidade: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-cidade">X</label>
                            </div>
                            <div class="col-md-4">
                                <label>Estado: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-estado">XX</label>
                            </div>
                        </div>
                        
                        <div class="row form-group">
                            <div class="col-md-12">
                                <label>CEP: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-cep">XXXXX-XXX</label>
                            </div>
                        </div>

                        <br>
                    </div>
                </div>
                <div class="row" id="divDoc" style="display: none">
                    <div class="col-md-12" style="background-color: white">
                        <br>

                        <div class="row">
                            <div class="col-md-4">
                                <label style="color: black; font-size: 16px">&nbsp;&nbsp;RG:</label><br>
                                <a id="text-doc-rg-link" target="_blank" href="#"><img id="text-doc-rg" style="max-width: 200px;  max-height: 100px;"/></a>
                            </div>
                            <div class="col-md-4">
                                <label style="color: black; font-size: 16px">&nbsp;&nbsp;CPF:</label><br>
                                <a id="text-doc-cpf-link" target="_blank" href="#"><img id="text-doc-cpf" style="max-width: 200px;  max-height: 100px;"/></a>
                            </div>
                            <div class="col-md-4">
                                <label style="color: black; font-size: 16px">&nbsp;&nbsp;Habilitação:</label><br>
                                <a id="text-doc-hab-link" target="_blank" href="#"><img id="text-doc-hab" style="max-width: 200px;  max-height: 100px;"/></a>
                            </div>
                        </div>
                        <br>
                    </div>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
            </div>
            
        </div>
    </div>
</div>

<script>
    function setaExcluir(cpf){
        document.getElementById('cpfcli').value = cpf;
    }
    function senha(){
        document.getElementById('formsenha').style.display = "block";
    }    
</script>

<script>
    function change(value){
        if(value == 1){
            document.getElementById('aDados').style = "background-color: white; cursor: pointer";
            document.getElementById('aEnd').style = "background-color: #eaeaea; cursor: pointer";
            document.getElementById('aDoc').style = "background-color: #eaeaea; cursor: pointer";
            
            document.getElementById('divDados').style.display = "block";
            document.getElementById('divEnd').style.display = "none";
            document.getElementById('divDoc').style.display = "none";
        }else if(value == 2){
            document.getElementById('aEnd').style = "background-color: white; cursor: pointer";
            document.getElementById('aDados').style = "background-color: #eaeaea; cursor: pointer";
            document.getElementById('aDoc').style = "background-color: #eaeaea; cursor: pointer";
            
            document.getElementById('divEnd').style.display = "block";
            document.getElementById('divDados').style.display = "none";
            document.getElementById('divDoc').style.display = "none";
        }else{
            document.getElementById('aDoc').style = "background-color: white; cursor: pointer";
            document.getElementById('aDados').style = "background-color: #eaeaea; cursor: pointer";
            document.getElementById('aEnd').style = "background-color: #eaeaea; cursor: pointer";
            
            document.getElementById('divDoc').style.display = "block";
            document.getElementById('divDados').style.display = "none";
            document.getElementById('divEnd').style.display = "none";
        }
    }
</script>

<script>

    $(document).ready(function(){
        $('#myTableCliente').DataTable( {
            "order": [[ 0, "asc" ]],
            "language": {
                "lengthMenu": "Mostrando _MENU_ registros por página",
                "zeroRecords": "Nada encontrado- refaça sua busca",
                "info": "Mostrando _PAGE_ de _PAGES_",
                "infoEmpty": "Sem registros disponíves",
                "infoFiltered": "(filtrado _MAX_ dos registros totais)",
                "sSearch":       "Procurar:",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Próximo",
                }
            },
            "columns": [
                {"CPF": "first", "orderable": true},
                {"Nome": "second", "orderable": true},
                {"Cidade": "third", "orderable": true},
                {"Estado": "fourth", "orderable": true},
                {"Ação": "fifth", "orderable": false},
            ],
            initComplete: function () {
                this.api().columns([0]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([1]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([2]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todas</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([3]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
            }
        } );
    });
</script>