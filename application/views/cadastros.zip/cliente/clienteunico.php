
<style>
    .user-data{
        font-size: 18px;
        color: black;
    }
    label{
        font-size: 16px;
    }
    .nav-tabs>li>a:hover{
        border-color: #f0f0f0 #f0f0f0 white;
        background-color: #f0f0f0!important;
    }
    .custom-img{
        max-width: 70%; 
        border: 1px solid #ccc;
    }
    .custom-img:hover{
        opacity: 0.8;
    }
</style>

<br>
<section id="main-content">
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-12">
                <h3>Clientes > Visualizar Cliente</h3>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <div class="row" style="margin-left: 0px; margin-right: 0px">
            <div class="col-md-12">
                
                <ul class="nav nav-tabs" id="myTab" role="tablist" style="background-color: #eaeaea">
                    <li class="nav-item">
                        <a class="nav-link" style="background-color: white; cursor: pointer; font-size: 18px" id="aDados" onclick="change(1)">Dados</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="cursor: pointer; font-size: 18px" id="aDoc" onclick="change(2)">Documentos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="cursor: pointer; font-size: 18px" id="aVend" onclick="change(3)">Vendas/Serviços</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="cursor: pointer; font-size: 18px" id="aVeic" onclick="change(4)">Veículos</a>
                    </li>
                </ul>
            
                <div class="row" id="divDados" style="display: block;">
                    <div class="col-md-12" style="background-color:white; border-radius: 5px">
                        <br><br>
                        
                        <div class="row">
                            <div class="col-md-9 form-group">
                                <h3>
                                    <?php echo $cliente['cliente_nome'].$cliente['cliente_fantasia'] ?>
                                </h3>
                            </div>
                            <div class="col-md-3 form-group" style="margin-top: 10px">
                                <?php if($cliente['cliente_ativo_id'] == 1){ ?>
                                <button disabled class="btn btn-success" style="font-size: 20px; float: right">Ativo</button>
                                <?php }else{ ?>
                                <button disabled class="btn btn-danger" style="font-size: 20px; float: right">Inativo</button>
                                <?php } ?>
                            </div>
                        </div>
                        
                        <hr style="height: 1px; background-color: #ccc; border: none;">
                        
                        <?php if($cliente['cliente_nome'] != null){ ?>
                        <div class="row">
                            <div class="col-md-4 form-group">
                                <label>CPF: &nbsp;</label>
                                <label class="user-data">
                                    <?php 
                                    echo substr($cliente['cliente_cpfcnpj'], 0, 3).".".substr($cliente['cliente_cpfcnpj'], 3, 3).".".substr($cliente['cliente_cpfcnpj'], 6, 3)."-".substr($cliente['cliente_cpfcnpj'], 9);
                                    ?>
                                </label>
                            </div>
                            <div class="col-md-4 form-group">
                                <label>RG: &nbsp;</label>
                                <label class="user-data">
                                    <?php echo $cliente['cliente_rg'] ?>
                                </label>
                            </div>
                            <div class="col-md-4 form-group">
                                <label>Nascimento: &nbsp;</label>
                                <label class="user-data">
                                    <?php 
                                    echo date("d/m/Y", strtotime($cliente['cliente_nascimento']));  
                                    ?>
                                </label>
                            </div>
                        </div>
                        <?php }else{ ?>
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label>CNPJ: &nbsp;</label>
                                <label class="user-data">
                                    <?php
                                    echo substr($cliente['cliente_cpfcnpj'], 0, 2).".".substr($cliente['cliente_cpfcnpj'], 2, 3).".".substr($cliente['cliente_cpfcnpj'], 5, 3)."/".substr($cliente['cliente_cpfcnpj'], 8, 4)."-".substr($cliente['cliente_cpfcnpj'], 12);
                                    ?>
                                </label>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Razão Social: &nbsp;</label>
                                <label class="user-data">
                                    <?php echo $cliente['cliente_razao'] ?>
                                </label>
                            </div>
                        </div>
                        <?php } ?>
                        
                        <br>
                        
                        <div class="row">
                            <div class="col-md-12 form-group">
                                <label>Logradouro: &nbsp;</label>
                                <label class="user-data">
                                    <?php 
                                    echo $cliente['cliente_endereco'].", ".$cliente['cliente_numero'];
                                    if($cliente['cliente_complemento'] != null){echo ", ".$cliente['cliente_complemento'];}
                                    echo " - ".$cliente['cliente_bairro']."; ".$cliente['cliente_cidade']." - ".$cliente['cliente_estado']." - ";
                                    echo substr($cliente['cliente_cep'], 0, 5)."-".substr($cliente['cliente_cep'], 5);
                                    ?>
                                </label>
                            </div>
                        </div>
                        
                        <br>
                        
                        <div class="row">
                            <div class="col-md-3 form-group">
                                <label>Telefone: &nbsp;</label>
                                <label class="user-data">
                                    <?php 
                                    echo "(".substr($cliente['cliente_fixo'], 0, 2).") ".substr($cliente['cliente_fixo'], 2, 4)."-".substr($cliente['cliente_fixo'], 6); 
                                    ?>
                                </label>
                            </div>
                            <div class="col-md-5 form-group">
                                <label>Celular: &nbsp;</label>
                                <label class="user-data">
                                    <?php 
                                    echo "(".substr($cliente['cliente_cel1'], 0, 2).") ".substr($cliente['cliente_cel1'], 2, 5)."-".substr($cliente['cliente_cel1'], 7); 
                                    if($cliente['cliente_cel2'] != null){
                                        echo " / (".substr($cliente['cliente_cel2'], 0, 2).") ".substr($cliente['cliente_cel2'], 2, 5)."-".substr($cliente['cliente_cel2'], 7);
                                    }
                                    ?>
                                </label>
                            </div>
                            <div class="col-md-4 form-group">
                                <label>E-mail: &nbsp;</label>
                                <label class="user-data">
                                    <?php echo $cliente['cliente_email'] ?>
                                </label>
                            </div>
                        </div>
                        
                        <br>
                        
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label>Benefício: &nbsp;</label>
                                <label class="user-data">
                                    <?php echo $cliente['cliente_beneficio1'] ?>
                                </label>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Benefício 2: &nbsp;</label>
                                <label class="user-data">
                                    <?php echo $cliente['cliente_beneficio2'] ?>
                                </label>
                            </div>
                        </div>
                        
                        <br><br>
                    </div>
                </div>
            
                <div class="row" id="divDocs" style="display: none;">
                    <div class="col-md-12" style="background-color:white; border-radius: 5px">
                        <br><br>
                        
                        <div class="row text-center">
                            <div class="col-md-4 form-group">
                                <label class="user-data">RG</label><br>
                                <a href="<?php echo base_url('uploads/').$cliente['cliente_cpfcnpj']."_rg.png" ?>" target="_blank" title="Visualizar">
                                    <img src="<?php echo base_url('uploads/').$cliente['cliente_cpfcnpj']."_rg.png" ?>" class="custom-img">
                                </a>
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="user-data">CPF</label><br>
                                <a href="<?php echo base_url('uploads/').$cliente['cliente_cpfcnpj']."_cpf.png" ?>" target="_blank" title="Visualizar">
                                    <img src="<?php echo base_url('uploads/').$cliente['cliente_cpfcnpj']."_cpf.png" ?>" class="custom-img">
                                </a>
                            </div>
                            <div class="col-md-4 form-group">
                                <label class="user-data">Habilitação</label><br>
                                <a href="<?php echo base_url('uploads/').$cliente['cliente_cpfcnpj']."_hab.png" ?>" target="_blank" title="Visualizar">
                                    <img src="<?php echo base_url('uploads/').$cliente['cliente_cpfcnpj']."_hab.png" ?>" class="custom-img">
                                </a>
                            </div>
                        </div>
                        
                        <br><br>
                    </div>
                </div>
                
                <div class="row" id="divVend" style="display: none;">
                    <div class="col-md-12" style="background-color:white; border-radius: 5px">
                        <br><br>
            
                        <br><br>
                    </div>
                </div>
                
                <div class="row" id="divVeic" style="display: none;">
                    <div class="col-md-12" style="background-color:white; border-radius: 5px">
                        <br><br>
            
                        <br><br>
                    </div>
                </div>
            
            </div>
        </div>
        
        <br><br>
    </section>
</section>

<script>
     function change(value){
        if(value == 1){
            document.getElementById('aDados').style.backgroundColor = "white";
            document.getElementById('aDoc').style.backgroundColor = "#eaeaea";
            document.getElementById('aVend').style.backgroundColor = "#eaeaea";
            document.getElementById('aVeic').style.backgroundColor = "#eaeaea";
            
            document.getElementById('divDados').style.display = "block";
            document.getElementById('divDocs').style.display = "none";
            document.getElementById('divVend').style.display = "none";
            document.getElementById('divVeic').style.display = "none";
        }else if(value == 2){
            document.getElementById('aDados').style.backgroundColor = "#eaeaea";
            document.getElementById('aDoc').style.backgroundColor = "white";
            document.getElementById('aVend').style.backgroundColor = "#eaeaea";
            document.getElementById('aVeic').style.backgroundColor = "#eaeaea";
            
            document.getElementById('divDados').style.display = "none";
            document.getElementById('divDocs').style.display = "block";
            document.getElementById('divVend').style.display = "none";
            document.getElementById('divVeic').style.display = "none";
        }else if(value == 3){
            document.getElementById('aDados').style.backgroundColor = "#eaeaea";
            document.getElementById('aDoc').style.backgroundColor = "#eaeaea";
            document.getElementById('aVend').style.backgroundColor = "white";
            document.getElementById('aVeic').style.backgroundColor = "#eaeaea";
            
            document.getElementById('divDados').style.display = "none";
            document.getElementById('divDocs').style.display = "none";
            document.getElementById('divVend').style.display = "block";
            document.getElementById('divVeic').style.display = "none";
        }else{
            document.getElementById('aDados').style.backgroundColor = "#eaeaea";
            document.getElementById('aDoc').style.backgroundColor = "#eaeaea";
            document.getElementById('aVend').style.backgroundColor = "#eaeaea";
            document.getElementById('aVeic').style.backgroundColor = "white";
            
            document.getElementById('divDados').style.display = "none";
            document.getElementById('divDocs').style.display = "none";
            document.getElementById('divVend').style.display = "none";
            document.getElementById('divVeic').style.display = "block";
        }
    }
</script>