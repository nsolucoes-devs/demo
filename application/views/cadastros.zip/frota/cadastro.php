<style>
    .inline{
        display: inline;
    }
    .disabled-field{}
</style>

<?php
    $iphone = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
    $ipad = strpos($_SERVER['HTTP_USER_AGENT'],"iPad");
    $android = strpos($_SERVER['HTTP_USER_AGENT'],"Android");
    $palmpre = strpos($_SERVER['HTTP_USER_AGENT'],"webOS");
    $berry = strpos($_SERVER['HTTP_USER_AGENT'],"BlackBerry");
    $ipod = strpos($_SERVER['HTTP_USER_AGENT'],"iPod");
    $symbian =  strpos($_SERVER['HTTP_USER_AGENT'],"Symbian");
    $auxfooter = 0;
    if ($iphone || $ipad || $android || $palmpre || $ipod || $berry || $symbian == true) {
        $phone = 1;
    } else {
        $phone = 0;
    }
?>

<script>
    $(document).ready(function(){
        
        //------------------- APPLY
        
        $("#placa").mask('AAA-AAAA', {'translation': {A: {pattern: /[A-Za-z0-9]/},}});
        $("#preco_compra").mask("#.##0,00", {reverse: true});
        $("#renavam").mask('00000000000');
        $("#chassi").mask('AAAAAAAAAAAAAAAAA', {'translation': {A: {pattern: /[A-Za-z0-9]/},}});
        $("#km").mask('0#');
        $("#tara").mask("#0,000", {reverse: true});
        $('.js-example-basic-multiple').select2({theme: "bootstrap"});
        
        
        //------------------- FUNCTIONS
        
        $("#ismunck").on('change', function(){
            if($("#ismunck").is(":checked")){
                $("#muncktypediv").css("display", "inline");
                $("#tipomunck").prop("disabled", false);
            }else{
                $("#muncktypediv").css("display", "none");
                $("#tipomunck").prop("disabled", true);
            }
        });
        
        $("#placa").keyup(function(){
            if($("#placa").val().length == 8){
                autoFillByPlaca($("#placa").val());
            }
        });
        
        function autofillById(id){
            var dados = {
                'frota_id': id
            };
        
            $.ajax({
                url : '<?php echo base_url('frota/getFrotaById') ?>',
                type : 'POST',
                dataType : 'json',
                data : dados,
                success : function(response) {
                    res = response[0];
                    treatAutofillData(res);
                },
                error : function(xhr, status, error) {
                    alert(status + " " + error + " " + xhr);
                }
            });
        }
        
        function treatAutofillData(data){
            
            $("#isedit").val(1);
            $("#id").val(data.frota_id);
            
            $("#placa").unmask().val(data.frota_placa).mask('AAA-AAAA');
            
            $("#codigo").val(data.frota_codigo);
            
            $("#chassi").val(data.frota_chassi);
            $("#renavam").val(data.frota_renavam);
            
            $("#modelo").val(data.frota_modelo_id).change();
            
            $("#ano").val(data.frota_ano);
            $("#cambio").val(data.frota_cambio);
            $("#cor").val(data.frota_cor);
            $("#linha").val(data.frota_linha_id).change();
            $("#preco_compra").unmask().val(data.frota_preco_compra.replace('.', ',')).mask("#.##0,00", {reverse: true});
            $("#km").val(data.frota_km);
            
            $("#pneu").val(data.frota_pneu_id).change();
            $("#tara").unmask().val(data.frota_tara.replace('.', ',')).mask("#0,000", {reverse: true});
            
            $("#tipogabine").val(data.frota_tipogabine_id);
            $("#tipogabine").change();
            
            $("#status").val(data.frota_status_id).change();
            $("#ativo").val(data.frota_ativo_id).change();
            
            if(data.frota_tipomunck_id != null){
                if(data.frota_tipomunck_id.length > 0){
                    $("#ismunck").trigger('click');
                    $("#tipomunck").val(data.frota_tipomunck_id);
                    $("#tipomunck").change();
                }
            }
        }
        
        function ver(id){
        var marcacao = "";
        <?php foreach($pneusIndividuais as $pneu){ ?>
            if(id == '<?php echo $pneu['pneus_individual_id'] ?>'){
                marcacao = '<?php echo $pneu['pneus_individual_marcacao'] ?>';
            }
        <?php } ?>
        $("#marcacao_v").html(marcacao);
        
        
        var registros = "";
        <?php foreach($pneusRegistros as $regp) { ?>
            if(id == '<?php echo $regp['pneus_registro_individual_id'] ?>'){
                registros += 
                "<tr>" +
                    "<td>" + 
                        "<?php echo date("d/m/Y H:i", strtotime($regp['pneus_registro_data'])) ?>" +
                    "</td>" +
                    "<td>" + 
                        "<?php echo $regp['pneus_registro_situacao'] ?>" +
                    "</td>" +
                    "<td>" + 
                        "<?php echo $regp['pneus_registro_observacao'] ?>" +
                    "</td>" +
                "</tr>";
            }
        <?php } ?>
        if(registros.length == 0){
            registros = "<tr class='odd'><td valign='top' colspan='3' class='dataTables_empty'>Nada encontrado- refaça sua busca</td></tr>";
        }
        $("#registros_v").html(registros);
        
        
        $("#myTableRegistros").change();
    }
        
        <?php if(isset($_GET['edicao_id'])){
            $edicao_id = $_GET['edicao_id'];
            echo "
                autofillById('" . $edicao_id . "');
            ";
        } ?>
    });
</script>

<script>
    function change(value){
        
        var div = $(".change-tab-div").toArray();
        var btn = $(".change-tab-btn").toArray();
        var affectedIndex = value - 1;
        
        div.forEach(function(v, i){
            if(i == affectedIndex){
                $(v).css('display', 'block');
            }else{
                $(v).css('display', 'none');
            }
        });
        
        btn.forEach(function(v, i){
            if(i == affectedIndex){
                $(v).css('background-color', 'white');
            }else{
                $(v).css('background-color', '#f0f0f0');
            }
        });
    }
</script>

<br>
<section id="main-content" style="margin-bottom: 30px">
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-12">
                <h3>Frota > <?php if(isset($_GET['edicao_id'])){echo 'Edição de Veículo';}else{echo 'Cadastro de Veículo';} ?></h3>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <form action="<?php echo base_url('frota/insertFrota') ?>" method="post">
            <div class="row" style="margin-left: 0px; margin-right: 0px">
                <div class="col-md-12">
                
                    <ul class="nav nav-tabs" id="myTab" role="tablist" style="background-color: #eaeaea">
                        <li class="nav-item">
                            <a class="nav-link change-tab-btn" style="background-color: white; cursor: pointer; font-size: 18px" id="aDados" onclick="change(1)">Dados</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link change-tab-btn" style="cursor: pointer; font-size: 18px; <?php if(!isset($_GET['edicao_id'])){echo "display:none;";} ?>" id="aPneus" onclick="change(2)">Pneus</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link change-tab-btn" style="cursor: pointer; font-size: 18px" id="aDocs" onclick="change(3)">Documentos</a>
                        </li>
                    </ul>
                    
                    <div id="divDados" class="change-tab-div">
                        <div class="col-md-12" style="background-color:white; border-radius: 5px">
                            <br><br>
                
                            <input type="hidden" id="isedit" name="isedit" <?php if(isset($_GET['edicao_id'])){echo "value='1'";} ?> />
                            <input type="hidden" id="id" name="id" <?php if(isset($_GET['edicao_id'])){echo "value='". $_GET['edicao_id'] ."'";} ?>/>
                            
                            <div class="row">
                                
                                <div class="col-md-6 form-group">
                                    <label for="placa">Placa</label><br>
                                    <input id="placa" name="placa" type="text" class="form-control" min="8" placeholder="Ex.: AAA-1A11" required/>
                                </div>
                                
                                <div class="col-md-6 form-group">
                                    <label for="codigo">Código da frota</label><br>
                                    <input id="codigo" name="codigo" type="text" class="form-control" placeholder="Ex.: 1A" maxlength="20" required>
                                </div>
                                
                            </div>
                            
                            <br>
                            
                            <div class="row">
                                
                                <div class="col-md-4 form-group">
                                    <label for="modelo">Modelo de Veículo</label><br>
                                    <select class="js-example-basic-multiple" style="width:100%;" name="modelo" id="modelo" required>
                                        <option selected value="">-- Selecionar --</option>
                                        <?php foreach($modelos as $modelo){ ?>
                                            <option value="<?php echo $modelo['frota_modelo_id'] ?>">
                                            <?php foreach($marcas as $marca){if($marca['frota_marca_id'] == $modelo['frota_modelo_marca_id']){ echo $marca['frota_marca_nome'] ; }} ?>
                                            <?php echo '&nbsp;|&nbsp;' . $modelo['frota_modelo_nome'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="tipogabine">Tipo de Gabine</label><br>
                                    <select class="js-example-basic-multiple" style="width:100%;" name="tipogabine" id="tipogabine" required>
                                        <option selected value="">-- Selecionar --</option>
                                        <?php foreach($tiposgabine as $tipogabine){ ?>
                                            <option value="<?php echo $tipogabine['frota_tipogabine_id'] ?>"><?php echo $tipogabine['frota_tipogabine_nome'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-1 form-group">
                                    <label for="ismunck" style="width:100%">Munck?</label><br>
                                    <input id="ismunck" name="ismunck" type="checkbox" value="1" />
                                </div>
                                
                                <div id="muncktypediv" class="col-md-3 form-group" style="display:none;">
                                    <label for="tipomunck">Tipo de Munck</label><br>
                                    <select class="js-example-basic-multiple" style="width:100%;" name="tipomunck" id="tipomunck" required disabled>
                                        <option selected value="">-- Selecionar --</option>
                                        <?php foreach($tiposmunck as $tipomunck){ ?>
                                            <option value="<?php echo $tipomunck['frota_tipomunck_id'] ?>"><?php echo $tipomunck['frota_tipomunck_nome'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                            </div>
                    
                            <br>
                    
                            <div class="row">
                                
                                <div class="col-md-4 form-group">
                                    <label for="linha">Linha de veículo</label><br>
                                    <select class="js-example-basic-multiple" style="width:100%;" name="linha" id="linha" required>
                                        <option selected>-- Selecionar --</option>
                                        <?php foreach($linhas as $linha){ ?>
                                            <option value="<?php echo $linha['frota_linha_id'] ?>"><?php echo $linha['frota_linha_nome'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-2 form-group">
                                    <label for="ano">Ano</label><br>
                                    <input id="ano" name="ano" type="number" class="form-control" onkeypress="$(this).mask('0000');" placeholder="Ex.: 1998" required />
                                </div>
                                
                                <div class="col-md-3 form-group">
                                    <label for="cor">Cor</label><br>
                                    <input id="cor" name="cor" type="text" class="form-control" placeholder="Ex.: Dourado" />
                                </div>
                                
                                <div class="col-md-3 form-group">
                                    <label for="cambio">Tipo de Câmbio</label><br>
                                    <input id="cambio" name="cambio" type="text" class="form-control" placeholder="Manual/Automatico" required />
                                </div>
                                
                            </div>
                            
                            <br>
                    
                            <div class="row">

                                <div class="col-md-4 form-group">
                                    <label for="renavam">Renavam</label><br>
                                    <input id="renavam" name="renavam" type="text" class="form-control" placeholder="Ex.: 21234567890" required />
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="chassi">Chassi</label><br>
                                    <input id="chassi" name="chassi" type="text" class="form-control" placeholder="Ex.: 9BA111AA11A000001" />
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="preco_compra">Preço de Compra(R$)</label><br>
                                    <input id="preco_compra" name="preco_compra" type="text" class="form-control" placeholder="0.00" required />
                                </div>
                                
                            </div>
                            
                            <br>
                    
                            <div class="row">

                                <div class="col-md-4 form-group">
                                    <label for="km">Quilometragem(Km)</label><br>
                                    <input id="km" name="km" type="text" class="form-control" placeholder="0" />
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="tara">Tara de Peso(Ton.)</label><br>
                                    <input id="tara" name="tara" type="text" class="form-control" placeholder="0" />
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="linha">Pneu de rodagem</label><br>
                                    <select class="js-example-basic-multiple" style="width:100%;" name="pneu" id="pneu" required>
                                        <option selected>-- Selecionar --</option>
                                        <?php foreach($pneus as $pneu){ ?>
                                            <option value="<?php echo $pneu['frota_pneu_id'] ?>"><?php echo $pneu['frota_pneu_marca'] . ' | Aro ' . $pneu['frota_pneu_aro'] . ' | ' . $pneu['frota_pneu_banda'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                            </div>
                            
                            <br>
                    
                            <div class="row" <?php if(!isset($_GET['edicao_id'])){ echo "style='display:none;'"; } ?>>
                                
                                <div class="col-md-6 form-group"> 
                                    <label for="status">Status/Situação</label><br>
                                    <select class="js-example-basic-multiple" style="width:100%;" name="status" id="status" required 
                                        <?php if(!isset($_GET['edicao_id'])){ echo "disabled"; } ?> >
                                        <option selected>-- Selecionar --</option>
                                        <?php foreach($status as $st){ ?>
                                            <option value="<?php echo $st['frota_status_id'] ?>"><?php echo $st['frota_status_nome'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-6 form-group"> 
                                    <label for="status">Ativação</label><br>
                                    <select class="js-example-basic-multiple" style="width:100%;" name="ativo" id="ativo" required 
                                        <?php if(!isset($_GET['edicao_id'])){ echo "disabled"; } ?> >
                                        <option selected>-- Selecionar --</option>
                                        <?php foreach($ativos as $ativo){ ?>
                                            <option value="<?php echo $ativo['ativo_id'] ?>"><?php echo $ativo['ativo_tipo'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                            </div>
                
                            <br><br>
                        </div>
                    </div>

                    <div id="divPneus" style="display:none;" class="change-tab-div">
                        <div class="col-md-12" style="background-color:white; border-radius: 5px">
                            <br><br>

                            <div class="row">
                                <div class="col-md-12">
                                    <h4>Pneus Vinculados</h4>
                                </div>
                            </div>
                            
                            <br><br>
                            
                            <div class="row">
                                <div class="col-md-12">
                                    <?php 
                                    $corresponding = 0;
                                    foreach($pneusIndividuais as $key => $value){
                                        if($value['pneus_individual_frota_id'] == $_GET['edicao_id']){
                                            $corresponding++;
                                        }
                                    }
                                    if(sizeof($pneusIndividuais) > 0 && $corresponding > 0){ ?>
                                    <table>
                                    <thead>
                                        <th width="5%">ID</th>
                                        <th width="10%">Marcação</th>
                                        <th width="15%">Tipo de Pneu</th>
                                        <th width="25%">Último Registro</th>
                                        <th width="6%">Registros</th>
                                        <th width="6%">Desvincular</th>
                                    </thead>
                                    <tbody>
                                        <?php 
                                            foreach($pneusIndividuais as $pi){ 
                                                if($pi['pneus_individual_frota_id'] == $_GET['edicao_id']){
                                        ?>
                                            <tr>
                                                <td><?php echo $pi['pneus_individual_id'] ?></td>
                                                <td><?php echo $pi['pneus_individual_marcacao'] ?></td>
                                                <td>
                                                <?php 
                                                    foreach($pneus as $tipopneu){
                                                        if($tipopneu['frota_pneu_id'] == $pi['pneus_individual_tipopneu_id']){
                                                            echo $tipopneu['frota_pneu_marca'] . ' | Aro: ' . $tipopneu['frota_pneu_aro'] . ' | Banda: ' . $tipopneu['frota_pneu_banda'];
                                                        }
                                                    }
                                                ?>
                                                </td>
                                                <td>
                                                <?php
                                                    if(sizeof($pneusRegistros) > 0){
                                                        $lastIndex = -1;
                                                        foreach($pneusRegistros as $key => $value){
                                                            if($value['pneus_registro_individual_id'] == $pi['pneus_individual_id']){
                                                                $lastIndex = $key;
                                                            }
                                                        }
                                                        if($lastIndex >= 0){
                                                            echo date("d/m/Y",strtotime($pneusRegistros[$lastIndex]['pneus_registro_data'])) . ' - ' . $pneusRegistros[$lastIndex]['pneus_registro_situacao'];
                                                            if(strlen($pneusRegistros[$lastIndex]['pneus_registro_observacao']) > 0){
                                                                echo ': ' . $pneusRegistros[$lastIndex]['pneus_registro_observacao'];
                                                            }
                                                        }
                                                        else{
                                                            echo " -- ";
                                                        }
                                                    }else{
                                                        echo " -- ";
                                                    }
                                                ?>
                                                </td>
                                                <td>
                                                    <a data-toggle="modal" data-target="#modalRegistros" class="btn btn-info" style="width:70%" onclick="registro(<?php echo $pi['pneus_individual_id'] ?>)"><i class="fab fa-wpforms"></i></a>
                                                </td>
                                                <td>
                                                    <a data-toggle="modal" data-target="#modalDesvincular" class="btn btn-danger" style="width:67%" onclick="desvincular(<?php echo $pi['pneus_individual_id'] ?>)"><i class="fas fa-unlink"></i></a>
                                                </td>
                                            </tr>
                                            <hr>
                                        <?php 
                                                }
                                            } 
                                        ?>
                                    </tbody>
                                    <tfoot>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                    </tfoot>
                                </table>
                                <?php }else if(sizeof($pneusIndividuais) == 0){ ?>
                                    <div class="text-center" style="width:100%">
                                        <br>
                                        <h5>Ainda não existem pneus cadastrados.</h5>
                                        <br><br>
                                    </div>
                                <?php }else if($corresponding == 0){ ?>
                                    <div class="text-center" style="width:100%">
                                        <br>
                                        <h5>Não existem pneus vinculados à este veículo.</h5>
                                        <br><br>
                                    </div>
                                <?php }else{ ?>
                                    <div class="text-center" style="width:100%">
                                        <br>
                                        <h5>Ocorreu um erro.</h5>
                                        <br><br>
                                    </div>
                                <?php } ?>
                                </div>
                            </div>
                            <br><br>
                        </div>
                    </div>
                    
                    <div id="divDocs" style="display:none;" class="change-tab-div">
                        <div class="col-md-12" style="background-color:white; border-radius: 5px">
                            <br><br>

                                DOCUMENTOS

                            <br><br>
                        </div>
                    </div>
                    
                </div>
            </div>
        
            <br><br>
        
            <div class="row" style="margin-bottom: 50px">
                <div class="col-md-12 text-center">
                    <a href="<?php echo base_url('frota/listagem') ?>" class="btn btn-danger">&nbsp&nbspCancelar&nbsp&nbsp</a>
                    &nbsp&nbsp&nbsp&nbsp
                    <button type="submit" id="btn-save" class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">&nbsp&nbspSalvar&nbsp&nbsp</button>
                </div>
            </div>
        </form>
    </section>
</section>

<!-- MODAL VER REGISTROS -->
<div class="modal fade" id="modalRegistros" tabindex="-1" role="dialog" aria-labelledby="modalVerLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalVerLabel">Visualizar Pneu vinculado</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4">
                        <label>Marcação:</label>
                        <h4 id="marcacao_v"></h4>
                    </div>
                    <div class="col-md-2">
                        <label>Ativação</label>
                        <h4 id="ativo_v"></h4>
                    </div>
                </div><br><br>
                <div class="row">
                    <div class="col-md-12">
                        <div class="tableFixHead">
                    <table id="myTableRegistros" class="table table-hover table-bordered">
                          <thead>
                                <tr>
                                    <th style="width:1%">Data</th>
                                    <th style="width:1%">Situação</th>
                                    <th style="width:10%">Observação</th>
                                </tr>
                            </thead>
                            <tbody id="registros_v">
                                <!-- -->
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </tfoot>
                    </table>
                </div>
                    </div>
                </div>
            </div>
        
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
            </div>

        </div>
    </div>
</div>
<!-- -->

<!-- MODAL DESVINCULAR -->
<div class="modal fade" id="modalDesvincular" tabindex="-1" role="dialog" aria-labelledby="modalExcluirTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalCadastroLabel">Desvincular Pneu</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="modal-body">
                <h4>Deseja realmente desvincular o Pneu deste Veículo?</h4>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white; float: left" onclick="senha()">&nbsp&nbspSim&nbsp&nbsp</button>
                <button class="btn btn-danger" data-dismiss="modal">&nbsp&nbspNão&nbsp&nbsp</button>
                <br><br>
                <div class="row" id="formsenha" style="display: none">
                    <div class="col-md-12 text-center">
                        <form action="<?php echo base_url('frota/desvincularPneuIndividual') ?>" method="post">
                            <input type="hidden" name="idpneu" id="idpneu">
                            <input type="hidden" name="edicao_id_save" id="edicao_id_save" value="<?php echo $_GET['edicao_id'] ?>">
                            <label style="font-size: 16px">Confirme a senha</label><br>
                            <input class="form-control" type="password" name="senha" id="senha" placeholder="Digite a Senha" required style="width: 50%; margin-left: 25%"><br>
                            <button type="submit" class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">&nbsp&nbspConfirmar&nbsp&nbsp</button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- -->

<script>
    function registro(id){
        var marcacao = "";
        <?php foreach($pneusIndividuais as $pneu){ ?>
            if(id == '<?php echo $pneu['pneus_individual_id'] ?>'){
                marcacao = '<?php echo $pneu['pneus_individual_marcacao'] ?>';
                if('<?php echo $pneu['pneus_individual_ativo_id'] ?>' == '1'){
                    $("#ativo_v").html('Ativo');    
                }else{
                    $("#ativo_v").html('Inativo');
                }
            }
        <?php } ?>
        $("#marcacao_v").html(marcacao);
        
        var registros = "";
        <?php foreach($pneusRegistros as $regp) { ?>
            if(id == '<?php echo $regp['pneus_registro_individual_id'] ?>'){
                registros += 
                "<tr>" +
                    "<td>" + 
                        "<?php echo date("d/m/Y H:i", strtotime($regp['pneus_registro_data'])) ?>" +
                    "</td>" +
                    "<td>" + 
                        "<?php echo $regp['pneus_registro_situacao'] ?>" +
                    "</td>" +
                    "<td>" + 
                        "<?php echo $regp['pneus_registro_observacao'] ?>" +
                    "</td>" +
                "</tr>";
            }
        <?php } ?>
        if(registros.length == 0){
            registros = "<tr class='odd'><td valign='top' colspan='3' class='dataTables_empty'>Nada encontrado- refaça sua busca</td></tr>";
        }
        $("#registros_v").html(registros);
        
        
        $("#myTableRegistros").change();
    }
    function desvincular(id){
        document.getElementById('idpneu').value = id;
    }
    function senha(){
        document.getElementById('formsenha').style.display = "block";
    }
</script>