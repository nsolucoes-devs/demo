<style>
    .tableFixHead          { overflow-y: auto; height: 450px; }
    .tableFixHead thead th { position: sticky; top: 0; }
    
    /* Just common table stuff. Really. */
    table  { border-collapse: collapse; width: 100%; }
    th, td { padding: 8px 16px; }
    th     { background:#eee; }
</style>

<br>
<section id="main-content">
    
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-6">
                <h3>Frota > Listagem de Veículos</h3>
            </div>
            <div class="col-md-6" style="text-align: right;">
                <a href="<?php echo base_url('frota/cadastro'); ?>" class="btn btn-success" style='margin-top: 20px; border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white'>Novo Veículo</a>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <div class="row" style="margin-left: 0px; margin-right: 0px">
            <div class="col-md-12" style="background-color: white;">
                
                <br>
                <div class="tableFixHead">
                <table id="myTableFrota" class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 30%">Veículo</th>
                                <th style="width: 4%">Placa</th>
                                <th style="width: 4%">Frota</th>
                                <th style="width: 8%">Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($frota as $veiculo){ 
                                if($this->session->userdata('f_a') != 1 && $tipo['frota_tipo_ativo_id'] != 2){  
                            ?>
                            <tr>
                                <td><!-- VEICULO -->
                                    <?php //PRINTAR MARCA
                                    foreach($modelos as $modelo){
                                        if($modelo['frota_modelo_id'] == $veiculo['frota_modelo_id']){
                                            foreach($marcas as $marca){
                                                if($marca['frota_marca_id'] == $modelo['frota_modelo_marca_id']){
                                                    echo $marca['frota_marca_nome'];
                                                }
                                            }   
                                        }
                                    } ?> - 
                                    <?php //PRINTAR MODELO
                                    foreach($modelos as $modelo){
                                        if($modelo['frota_modelo_id'] == $veiculo['frota_modelo_id']){
                                            echo $modelo['frota_modelo_nome'];
                                        }
                                    }
                                    ?> (
                                    
                                    <?php //PRINTAR GABINE 
                                    foreach($tiposgabine as $tipogabine){
                                        if($tipogabine['frota_tipogabine_id'] == $veiculo['frota_tipogabine_id']){
                                            echo 'Gabine: ' . $tipogabine['frota_tipogabine_nome'];
                                        }
                                    }
                                    ?>
                                    
                                    <?php //PRINTAR MUNCK 
                                    
                                    if($veiculo['frota_tipomunck_id'] != null){
                                        if(strlen($veiculo['frota_tipomunck_id']) > 0){
                                            foreach($tiposmunck as $tipomunck){
                                                if($tipomunck['frota_tipomunck_id'] == $veiculo['frota_tipomunck_id']){
                                                    echo '; Munck: ' . $tipomunck['frota_tipomunck_nome'];
                                                }
                                            }
                                        }
                                    }
                                    
                                    ?>
                                    
                                    )
                                    
                                </td> <!-- VEICULO -->
                                <td><?php echo $veiculo['frota_placa'] ?></td> <!-- PLACA -->
                                <td><?php echo $veiculo['frota_codigo'] ?></td> <!-- FROTA -->
                                <td>
                                    <?php if($this->session->userdata('f_v') == 1){ ?>
                                    <a style="font-size: 12px" href="<?php echo base_url('frota/verFrota/') . $veiculo['frota_id'] ?>" class="btn btn-primary btn-modal-toggle"><i class="fas fa-eye"></i></a>
                                    <?php } ?>
                                    <?php if($this->session->userdata('f_e') == 1){ ?>
                                    <a style="font-size: 12px" href="<?php echo base_url('frota/') . 'cadastro?edicao_id=' . $veiculo['frota_id'] ?>" class="btn btn-primary" ><i class="fas fa-pencil-alt"></i></a>
                                    <?php } ?>
                                    <?php if($this->session->userdata('f_d') == 1){ ?>
                                    <a id="modalExcluirTitle" data-toggle="modal" data-target="#modalExcluir" style="font-size: 12px" class="btn btn-danger" onclick="setaExcluir('<?php echo $veiculo['frota_placa'] ?>')"><i class="fas fa-trash"></i></a>
                                    <?php } ?>
                                </td>
                            </tr>
                            <?php }else if($this->session->userdata('f_a') == 1){ ?>
                                <tr <?php if($veiculo['frota_ativo_id'] == 2){echo "style='background-color: #eaeaea'";} ?>>
                                <td><!-- VEICULO -->
                                    <?php //PRINTAR MARCA
                                    foreach($modelos as $modelo){
                                        if($modelo['frota_modelo_id'] == $veiculo['frota_modelo_id']){
                                            foreach($marcas as $marca){
                                                if($marca['frota_marca_id'] == $modelo['frota_modelo_marca_id']){
                                                    echo $marca['frota_marca_nome'];
                                                }
                                            }   
                                        }
                                    } ?> - 
                                    <?php //PRINTAR MODELO
                                    foreach($modelos as $modelo){
                                        if($modelo['frota_modelo_id'] == $veiculo['frota_modelo_id']){
                                            echo $modelo['frota_modelo_nome'];
                                        }
                                    }
                                    ?> (
                                    
                                    <?php //PRINTAR GABINE 
                                    foreach($tiposgabine as $tipogabine){
                                        if($tipogabine['frota_tipogabine_id'] == $veiculo['frota_tipogabine_id']){
                                            echo 'Gabine: ' . $tipogabine['frota_tipogabine_nome'];
                                        }
                                    }
                                    ?>
                                    
                                    <?php //PRINTAR MUNCK 
                                    
                                    if($veiculo['frota_tipomunck_id'] != null){
                                        if(strlen($veiculo['frota_tipomunck_id']) > 0){
                                            foreach($tiposmunck as $tipomunck){
                                                if($tipomunck['frota_tipomunck_id'] == $veiculo['frota_tipomunck_id']){
                                                    echo '; Munck: ' . $tipomunck['frota_tipomunck_nome'];
                                                }
                                            }
                                        }
                                    }
                                    
                                    ?>
                                    
                                    )
                                    
                                </td> <!-- VEICULO -->
                                <td><?php echo $veiculo['frota_placa'] ?></td> <!-- PLACA -->
                                <td><?php echo $veiculo['frota_codigo'] ?></td> <!-- FROTA -->
                                <td>
                                    <?php if($this->session->userdata('f_v') == 1){ ?>
                                    <a style="font-size: 12px" href="<?php echo base_url('frota/verFrota/') . $veiculo['frota_id'] ?>" class="btn btn-primary btn-modal-toggle"><i class="fas fa-eye"></i></a>
                                    <?php } ?>
                                    <?php if($this->session->userdata('f_e') == 1){ ?>
                                    <a style="font-size: 12px" href="<?php echo base_url('frota/') . 'cadastro?edicao_id=' . $veiculo['frota_id'] ?>" class="btn btn-primary" ><i class="fas fa-pencil-alt"></i></a>
                                    <?php } ?>
                                    <?php if($this->session->userdata('f_d') == 1){ ?>
                                    <a id="modalExcluirTitle" data-toggle="modal" data-target="#modalExcluir" style="font-size: 12px" class="btn btn-danger" onclick="setaExcluir('<?php echo $veiculo['frota_placa'] ?>')"><i class="fas fa-trash"></i></a>
                                    <?php } ?>
                                </td>
                            </tr>
                            <?php }
                                }
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Veículo</th>
                                <th>Placa</th>
                                <th>Frota</th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                    </div>
            </div>
        </div>
    </section>
</section>

<!-- modalExcluir -->
<div class="modal fade" id="modalExcluir" tabindex="-1" role="dialog" aria-labelledby="modalExcluirTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Mensagem do Sistema</h5>
            </div>
            <div class="modal-body">
                <h4>Deseja realmente excluir o veículo da frota?</h4>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white; float: left" onclick="senha()">&nbsp&nbspSim&nbsp&nbsp</button>
                <button class="btn btn-danger" data-dismiss="modal">&nbsp&nbspNão&nbsp&nbsp</button>
                <br><br>
                <div class="row" id="formsenha" style="display: none">
                    <div class="col-md-12 text-center">
                        <form action="<?php echo base_url('frota/deleteFrota') ?>" method="post">
                            <input type="hidden" name="idfrota" id="idfrota">
                            <label style="font-size: 16px">Confirme a senha</label><br>
                            <input class="form-control" type="password" name="senha" id="senha" placeholder="Digite a Senha" required style="width: 50%; margin-left: 25%"><br>
                            <button type="submit" class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">&nbsp&nbspConfirmar&nbsp&nbsp</button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalFrota" tabindex="-1" role="dialog" aria-labelledby="modalVerLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalVerLabel">Visualização de <p id="linha_v" style="display:inline; padding:0px; margin:0px;">Veículo</p> da Frota</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-8 form-group">
                        <label style="font-size: 19px;">Veículo: </label><br>&nbsp;&nbsp; <!-- marca - modelo (ano) -->
                        <label id="automovel_v" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">Frota: </label><br>&nbsp;&nbsp;
                        <label id="codigo_v" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8 form-group">
                        <label style="font-size: 19px;">Tipo de Pneus: <br>&nbsp;&nbsp;
                        <label id="pneu_v" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-2 form-group">
                        <label style="font-size: 19px;">Câmbio: </label><br>&nbsp;&nbsp;
                        <label id="cambio_v" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-2 form-group">
                        <label style="font-size: 19px;">Cor: </label><br>&nbsp;&nbsp;
                        <label id="cor_v" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <label style="font-size: 19px;">Placa: <br>&nbsp;&nbsp;
                        <label id="placa_v" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-4 form-group">
                        <label style="font-size: 19px;">Chassi: <br>&nbsp;&nbsp;
                        <label id="chassi_v" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-4 form-group">
                        <label style="font-size: 19px;">Renavam: <br>&nbsp;&nbsp;
                        <label id="renavam_v" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label style="font-size: 19px;">Tipo de Gabine: </label><br>&nbsp;&nbsp;
                        <label id="tipogabine_v" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-6 form-group">
                        <label style="font-size: 19px;">Tipo de Munck: </label><br>&nbsp;&nbsp;
                        <label id="tipomunck_v" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label style="font-size: 19px;">Última quilometragem: <br>&nbsp;&nbsp;
                        <label id="km_v" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-6 form-group">
                        <label style="font-size: 19px;">Peso/Tara (Ton.): <br>&nbsp;&nbsp;
                        <label id="tara_v" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label style="font-size: 19px;">Status/Situação: <br>&nbsp;&nbsp;
                        <label id="status_v" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-6 form-group">
                        <label style="font-size: 19px;">Ativação: <br>&nbsp;&nbsp;
                        <label id="ativo_v" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
            </div>
        
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
            </div>

        </div>
    </div>
</div>

<script>
    function ver(id){
        var dados = {
            'frota_id': id
        };
                
        $.ajax({
            url : '<?php echo base_url('frota/getFrotaById') ?>',
            type : "POST",
            dataType : "json",
            data : dados,
            success : function(response) {
                res = response[0];
                
                var linha = "--";
                <?php foreach($linhas as $linha){ ?>
                    if(res.frota_linha_id == <?php echo $linha['frota_linha_id'] ?>){
                        linha = '<?php echo $linha['frota_linha_nome'] ?>'; 
                    }
                <?php } ?>
                $("#linha_v").html(linha);
                
                var automovel = "--";
                <?php foreach($modelos as $modelo){ ?>
                    if(res.frota_modelo_id == <?php echo $modelo['frota_modelo_id'] ?>){
                        <?php foreach($marcas as $marca) { ?>
                            if(<?php echo $modelo['frota_modelo_marca_id'] ?> == <?php echo $marca['frota_marca_id'] ?>){
                                automovel = '<?php echo $marca['frota_marca_nome'] ?>' + ' ' + '<?php echo $modelo['frota_modelo_nome'] ?>' + ' (' + res.frota_ano + ')';
                            }
                        <?php } ?>
                    }
                <?php } ?>
                $("#automovel_v").html(automovel);
                
                $("#codigo_v").html(res.frota_codigo);
                if(res.frota_chassi != null){
                    if(res.frota_chassi.length > 0){
                        $("#chassi_v").html(res.frota_chassi);
                    }
                }
                if(res.frota_cor != null){
                    if(res.frota_cor.length > 0){
                        $("#cor_v").html(res.frota_cor);
                    }
                }
                if(res.frota_placa != null){
                    if(res.frota_placa.length > 0){
                        $("#placa_v").unmask().html(res.frota_placa).mask('AAA-AAAA');
                    }
                }
                $("#cambio_v").html(res.frota_cambio);
                $("#renavam_v").html(res.frota_renavam);
                if(res.frota_km != null){
                    if(res.frota_km.length > 0){
                        $("#km_v").html(res.frota_km + " Km");
                    }
                }
                if(res.frota_tara != null){
                    if(res.frota_tara.length > 0){
                        $("#tara_v").html(res.frota_tara);
                    }
                }
                
                
                var status = "--";
                <?php foreach($status as $st){ ?>
                    if(res.frota_status_id == <?php echo $st['frota_status_id'] ?>){
                        status = '<?php echo $st['frota_status_nome'] ?>'; 
                    }
                <?php } ?>
                $("#status_v").html(status);
                
                var pneu = "--";
                <?php foreach($pneus as $pneu){ ?>
                    if(res.frota_pneu_id == <?php echo $pneu['frota_pneu_id'] ?>){
                        pneu = '<?php echo $pneu['frota_pneu_marca'] ?>' + ' -  Aro: ' + '<?php echo $pneu['frota_pneu_aro'] ?>' + ' - Banda: ' + '<?php echo $pneu['frota_pneu_banda'] ?>';  
                    }
                <?php } ?>
                $("#pneu_v").html(pneu);
                
                var tipogabine = "--";
                <?php foreach($tiposgabine as $tipogabine){ ?>
                    if(res.frota_tipogabine_id == <?php echo $tipogabine['frota_tipogabine_id'] ?>){
                         tipogabine = '<?php echo $tipogabine['frota_tipogabine_nome'] ?>';  
                    }
                <?php } ?>
                $("#tipogabine_v").html(tipogabine);
                
                var tipomunck = "--";
                <?php foreach($tiposmunck as $tipomunck){ ?>
                    if(res.frota_tipomunck_id == <?php echo $tipomunck['frota_tipomunck_id'] ?>){
                        tipomunck = '<?php echo $tipomunck['frota_tipomunck_nome'] ?>';  
                    }
                <?php } ?>
                $("#tipomunck_v").html(tipomunck);
                
                if(res.frota_ativo_id == 2){
                    $("#ativo_v").html('Inativo');
                }else{
                    $("#ativo_v").html('Ativo');
                }
            },
            error : function(xhr, status, error) {
                alert(status + " " + error + " " + xhr);
            }
        });
    }
    function setaExcluir(id){
        document.getElementById('idfrota').value = id;
    }
    function senha(){
        document.getElementById('formsenha').style.display = "block";
    }
</script>

<script>
    $(document).ready(function(){
        
        $('#myTableFrota').DataTable( {
            "order": [[ 0, "asc" ]],
            "language": {
                "lengthMenu": "Mostrando _MENU_ registros por página",
                "zeroRecords": "Nada encontrado- refaça sua busca",
                "info": "Mostrando _PAGE_ de _PAGES_",
                "infoEmpty": "Sem registros disponíves",
                "infoFiltered": "(filtrado _MAX_ dos registros totais)",
                "sSearch":       "Procurar:",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Próximo",
                }
            },
            "columns": [
                {"Veículo": "first", "orderable": true},
                {"Placa": "second", "orderable": true},
                {"Frota": "third", "orderable": true},
                {"Ação": "fourth", "orderable": false},
            ],
            initComplete: function () {
                this.api().columns([0]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([1]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([2]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todas</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
            }
        });
    });
</script>