
<style>
    .see-data{
        color: black;
        font-size: 16px;
    }
    .see-place{
        font-size: 14px;
    }
</style>

<!-- <label class="see-place"></label><label class="see-data"></label> -->

<br>
<section id="main-content" style="margin-bottom: 30px">
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-12">
                <h3>Frota > Visualização</h3>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <div class="row" style="margin-left: 0px; margin-right: 0px">
            <div class="col-md-12" style="background-color:white; border-radius: 5px">
                <br>
                
                <div class="row">
                    <div class="col-md-12">
                        <a style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white" class="btn btn-primary" href="<?php echo base_url('frota/listagem') ?>"><i class="fas fa-chevron-left"></i>&nbsp; Voltar</a>
                    </div>
                </div>
                
                <br>
                
                <div class="row">
                    <div class="col-md-3 form-group">
                        <label class="see-place">Placa: &nbsp;</label><label class="see-data"><?php echo $frota['frota_placa'] ?></label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label class="see-place">Código da Frota: &nbsp;</label><label class="see-data"><?php echo $frota['frota_codigo'] ?></label>
                    </div>
                    <div class="col-md-6 form-group">
                        <label class="see-place">Modelo do Veículo: &nbsp;</label><label class="see-data"><?php echo $modelo ?></label>
                    </div>
                </div>
                
                <br>
                
                <div class="row">
                    <div class="col-md-3 form-group">
                        <label class="see-place">Câmbio: &nbsp;</label><label class="see-data"><?php echo $frota['frota_cambio'] ?></label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label class="see-place">Cor: &nbsp;</label><label class="see-data"><?php echo $frota['frota_cor'] ?></label>
                    </div>
                    <div class="col-md-6 form-group">
                        <label class="see-place">Tipo de Pneus: &nbsp;</label><label class="see-data"><?php echo $pneu ?></label>
                    </div>
                </div>
                
                <br>
                
                <div class="row">
                    <div class="col-md-3 form-group">
                        <label class="see-place">Chassi: &nbsp;</label><label class="see-data"><?php echo $frota['frota_chassi'] ?></label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label class="see-place">Renavam: &nbsp;</label><label class="see-data"><?php echo $frota['frota_renavam'] ?></label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label class="see-place">Status/Situação: &nbsp;</label><label class="see-data"><?php echo $status ?></label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label class="see-place">Ativação: &nbsp;</label><label class="see-data"><?php echo $frota['frota_ativo_id'] ?></label>
                    </div>
                </div>
                
                <br>
                
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label class="see-place">Tipo de Cabine: &nbsp;</label><label class="see-data"><?php echo $cabine['frota_tipogabine_nome'] ?></label>
                    </div>
                    <div class="col-md-6 form-group">
                        <label class="see-place">Tipo de Munck: &nbsp;</label><label class="see-data"><?php echo $munck ?></label>
                    </div>
                </div>
                
                <br><br>
            </div>
        </div>
        
    </section>
</section>