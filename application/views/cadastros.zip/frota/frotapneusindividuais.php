<style>
    .tableFixHead          { overflow-y: auto; height: 600px; }
    .tableFixHead thead th { position: sticky; top: 0; }
    
    /* Just common table stuff. Really. */
    table  { border-collapse: collapse; width: 100%; }
    th, td { padding: 8px 16px; }
    th     { background:#eee; }
</style>

<br>
<section id="main-content">
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-6">
                <h3>Frota > Cadastro de Pneus</h3>
            </div>
            <div class="col-md-6" style="text-align: right;">
                <a data-toggle="modal" data-target="#modalIndividual" class="btn btn-primary" style="margin-top: 20px; border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">Cadastro de Pneu</a>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <div class="row" style="margin-left: 0px; margin-right: 0px">
            <div class="col-md-12" style="background-color: white;">
                <br>
                
                <?php if($erro == 1){ ?>
                <div class="row">
                    <div class="col-md-12 form-group">
                        <h4 class="text-danger">Erro: A senha informada estava incorreta, por favor tente novamente!</h4>
                    </div>
                </div>
                <?php } ?>
                
                <div class="tableFixHead">
                    <table id="myTableTipo" class="table table-hover table-bordered">
                          <thead>
                                <tr>
                                    <th style="width:1%">ID</th>
                                    <th style="width:2%">Marcação</th>
                                    <th style="width:6%">Tipo</th>
                                    <th style="width:5%">Vinculado à</th>
                                    <th style="width:6%">Ação</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                foreach($pneus as $pneu){ 
			                        if($this->session->userdata('f_a') != 1 && $pneu['frota_pneu_ativo_id'] != 2){    
                                ?>
                                <tr>
                                    <td><?php echo $pneu['pneus_individual_id'] ?></td>
                                    <td><?php echo mb_strtoupper($pneu['pneus_individual_marcacao']) ?></td>
                                    <td>
                                        <?php 
                                            foreach($tipospneu as $tipopneu){
                                                if($tipopneu['frota_pneu_id'] == $pneu['pneus_individual_tipopneu_id']){
                                                    echo mb_strtoupper($tipopneu['frota_pneu_marca'] . ' | Aro: ' . $tipopneu['frota_pneu_aro'] . ' | Banda: ' . $tipopneu['frota_pneu_banda']);
                                                }    
                                            } 
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                            if($pneu['pneus_individual_frota_id'] == 0){
                                                echo 'Nenhum';
                                            }else{
                                                foreach($frota as $veiculo){
                                                    if($veiculo['frota_id'] == $pneu['pneus_individual_frota_id']){
                                                        foreach($modelos as $modelo){
                                                            if($modelo['frota_modelo_id'] == $veiculo['frota_modelo_id']){
                                                                foreach($marcas as $marca){
                                                                    if($marca['frota_marca_id'] == $modelo['frota_modelo_marca_id']){
                                                                        echo $veiculo['frota_id'] . ' | ' . $marca['frota_marca_nome'] . ' ' . $modelo['frota_modelo_nome']; 
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if($this->session->userdata('f_e') == 1){ ?>
    			                        <a style="font-size: 12px" data-toggle="modal" data-target="#modalRegistro" onclick="registro('<?php echo $pneu['pneus_individual_id']?>', '<?php echo $pneu['pneus_individual_marcacao'] ?>')" class="btn btn-info btn-modal-toggle" alt="Novo Registro" title="Novo Registro"><i class="fab fa-wpforms"></i></a>
    			                        &nbsp;&nbsp;
    			                        <?php } ?>
    			                        <?php if($this->session->userdata('f_v') == 1){ ?>
    			                        <a data-toggle="modal" data-target="#modalVer" onclick="ver(<?php echo $pneu['pneus_individual_id'] ?>)" class="btn btn-primary" style="font-size: 12px" alt="Ver" title="Ver"><i class="fas fa-eye"></i></a>
    			                        &nbsp;&nbsp;
    			                        <?php } ?>
    			                        <?php if($this->session->userdata('f_e') == 1){ ?>
    			                        <a data-toggle="modal" data-target="#modalEditar" onclick="editar(<?php echo $pneu['pneus_individual_id'] ?>)" class="btn btn-primary" style="font-size: 12px" alt="Editar Pneu" title="Editar Pneu"><i class="fas fa-pencil-alt"></i></a>
    			                        &nbsp;&nbsp;
    			                        <?php } ?>
    			                        <?php if($this->session->userdata('f_d') == 1){ ?>
    			                        <a data-toggle="modal" data-target="#modalExcluir" class="btn btn-danger" style="font-size: 12px" onclick="excluir('<?php echo $pneu['pneus_individual_id'] ?>')" alt="Inativar Pneu" title="Inativar Pneu"><i class="fas fa-trash"></i></a>
    			                        <?php } ?>
                                    </td>
                                </tr>
                                <?php }else if($this->session->userdata('f_a') == 1){ ?>
                                <tr <?php if($pneu['pneus_individual_ativo_id'] == 2){echo "style='background-color: #eaeaea'";} ?>>
                                    <td><?php echo $pneu['pneus_individual_id'] ?></td>
                                    <td><?php echo $pneu['pneus_individual_marcacao'] ?></td>
                                    <td>
                                        <?php 
                                            foreach($tipospneu as $tipopneu){
                                                if($tipopneu['frota_pneu_id'] == $pneu['pneus_individual_tipopneu_id']){
                                                    echo $tipopneu['frota_pneu_marca'] . ' | Aro: ' . $tipopneu['frota_pneu_aro'] . ' | Banda: ' . $tipopneu['frota_pneu_banda'];
                                                }    
                                            } 
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                            if($pneu['pneus_individual_frota_id'] == 0){
                                                echo 'Nenhum';
                                            }else{
                                                foreach($frota as $veiculo){
                                                    if($veiculo['frota_id'] == $pneu['pneus_individual_frota_id']){
                                                        foreach($modelos as $modelo){
                                                            if($modelo['frota_modelo_id'] == $veiculo['frota_modelo_id']){
                                                                foreach($marcas as $marca){
                                                                    if($marca['frota_marca_id'] == $modelo['frota_modelo_marca_id']){
                                                                        echo $veiculo['frota_id'] . ' | ' . $marca['frota_marca_nome'] . ' ' . $modelo['frota_modelo_nome']; 
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if($this->session->userdata('f_e') == 1){ ?>
    			                        <a style="font-size: 12px" data-toggle="modal" data-target="#modalRegistro" onclick="registro('<?php echo $pneu['pneus_individual_id']?>', '<?php echo $pneu['pneus_individual_marcacao'] ?>')" class="btn btn-info btn-modal-toggle" alt="Novo Registro" title="Novo Registro"><i class="fab fa-wpforms"></i></a>
    			                        &nbsp;&nbsp;
    			                        <?php } ?>
    			                        <?php if($this->session->userdata('f_v') == 1){ ?>
    			                        <a data-toggle="modal" data-target="#modalVer" onclick="ver(<?php echo $pneu['pneus_individual_id'] ?>)" class="btn btn-primary" style="font-size: 12px" alt="Ver" title="Ver"><i class="fas fa-eye"></i></a>
    			                        &nbsp;&nbsp;
    			                        <?php } ?>
    			                        <?php if($this->session->userdata('f_e') == 1){ ?>
    			                        <a data-toggle="modal" data-target="#modalEditar" onclick="editar(<?php echo $pneu['pneus_individual_id'] ?>)" class="btn btn-primary" style="font-size: 12px" alt="Editar" title="Editar"><i class="fas fa-pencil-alt"></i></a>
    			                        &nbsp;&nbsp;
    			                        <?php } ?>
    			                        <?php if($this->session->userdata('f_d') == 1){ ?>
    			                        <a data-toggle="modal" data-target="#modalExcluir" class="btn btn-danger" style="font-size: 12px" onclick="excluir('<?php echo $pneu['pneus_individual_id'] ?>' )" alt="Inativar" title="Inativar"><i class="fas fa-trash"></i></a>
    			                        <?php } ?>
                                    </td>
                                </tr>
                                <?php } } ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>ID</th>
                                    <th>Marcação</th>
                                    <th>Tipo</th>
                                    <th>Vinculado à</th>
                                    <th></th>
                                </tr>
                            </tfoot>
                    </table>
                </div>
                
                <br> 
            </div>
        </div>
        <br><br>
    </section>
</section>


<div class="modal fade" id="modalRegistro" tabindex="-1" role="dialog" aria-labelledby="modalVinculoLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalCadastroLabel">Novo Registro de Situação de Pneu</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <form method="post" action="<?php echo base_url('frota/insertRegistroPneu') ?>">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 form-group">
                            <input type="hidden" id="registro_individual_id" name="registro_individual_id" required/>
                            <label>Pneu Alvo</label><br>
                            <input type="text" class="form-control" id="registro_individual_id_show" name="registro_individual_id_show" disabled/>
                        </div>
                    </div><br>
                    <div class="row">
                        <div class="col-md-12">
                            <label>Situação</label><br>
                            <input type="text" class="form-control" id="registro_situacao" name="registro_situacao" placeholder="Ex.: Novo, semi-novo, usado, reparo ..." required>
                        </div>
                    </div><br>
                    <div class="row">
                        <div class="col-md-12">
                            <label>Observação</label><br>
                            <textarea type="text" class="form-control" id="registro_observacao" name="registro_observacao" 
                            style="resize:none;" rows="3" placeholder="..."></textarea>
                        </div>
                    </div><br>
                </div>
            
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" style="float: left">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Lançar</button>
                </div>
            </form>
            
        </div>
    </div>
</div>

<div class="modal fade" id="modalIndividual" tabindex="-1" role="dialog" aria-labelledby="modalVinculoLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalCadastroLabel">Cadastro de Pneu Individual</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <form method="post" action="<?php echo base_url('frota/insertPneuIndividual') ?>">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <label>Tipo de Pneu</label>
                            <select class="js-example-basic-multiple" style="width:100%;" name="individual_tipopneu" id="individual_tipopneu" required>
                                <option selected value="">-- Selecionar --</option>
                                <?php foreach($tipospneu as $tipopneu){ ?>
                                    <option value="<?php echo $tipopneu['frota_pneu_id'] ?>"><?php echo $tipopneu['frota_pneu_marca'] . ' | Aro: ' . $tipopneu['frota_pneu_aro'] . ' | Banda: ' . $tipopneu['frota_pneu_banda'] ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div><br>
                    <div class="row">
                        <div class="col-md-12">
                            <label>Veículo vinculado</label>
                            <select class="js-example-basic-multiple" style="width:100%;" name="individual_frota" id="individual_frota" required>
                                <option selected value="">-- Selecionar --</option>
                                <option value="0">Nenhum</option>
                                <?php foreach($frota as $veiculo){ ?>
                                    <option value="<?php echo $veiculo['frota_id'] ?>">
                                        <?php 
                                            foreach($modelos as $modelo){
                                                if($modelo['frota_modelo_id'] == $veiculo['frota_modelo_id']){
                                                    foreach($marcas as $marca){
                                                        if($marca['frota_marca_id'] == $modelo['frota_modelo_marca_id']){
                                                            
                                                            echo $veiculo['frota_id'] . ' | ' . $marca['frota_marca_nome'] . ' ' . $modelo['frota_modelo_nome'];
                                                            
                                                            if(isset($veiculo['frota_cor']) && !empty($veiculo['frota_cor'])){
                                                                echo ' (' . $veiculo['frota_cor'] . ')';
                                                            }
                                                            
                                                            if(isset($veiculo['frota_placa']) && !empty($veiculo['frota_placa'])){
                                                                echo ' - ' . $veiculo['frota_placa'];
                                                            }
                                                            
                                                            if(isset($veiculo['frota_chassi']) && !empty($veiculo['frota_chassi'])){
                                                                echo ' - ' . $veiculo['frota_chassi'];
                                                            }
                                                            
                                                            if(isset($veiculo['frota_renavam']) && !empty($veiculo['frota_renavam'])){
                                                                echo ' - ' . $veiculo['frota_renavam'];
                                                            }
                                                            
                                                        }
                                                    }
                                                }
                                            }
                                        ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                    </div><br>
                    <div class="row">
                        <div class="col-md-12">
                            <label>Marcação do Pneu</label><br>
                            <input type="text" class="form-control" id="individual_marcacao" name="individual_marcacao" placeholder="Ex.: 225/55 R 17 97 W" required>
                        </div>
                    </div><br>
                </div>
            
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" style="float: left">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Cadastrar</button>
                </div>
            </form>
            
        </div>
    </div>
</div>

<div class="modal fade" id="modalVer" tabindex="-1" role="dialog" aria-labelledby="modalVerLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalVerLabel">Visualizar Pneu</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4">
                        <label>Marcação:</label>
                        <h4 id="marcacao_v"></h4>
                    </div>
                    <div class="col-md-6">
                        <label>Atualmente vinculado à:</label>
                        <h4 id="vinculo_v"></h4>
                    </div>
                    <div class="col-md-2">
                        <label>Ativação</label>
                        <h4 id="ativo_v"></h4>
                    </div>
                </div><br><br>
                <div class="row">
                    <div class="col-md-12">
                        <div class="tableFixHead">
                    <table id="myTableRegistros" class="table table-hover table-bordered">
                          <thead>
                                <tr>
                                    <th style="width:1%">Data</th>
                                    <th style="width:1%">Situação</th>
                                    <th style="width:10%">Observação</th>
                                </tr>
                            </thead>
                            <tbody id="registros_v">
                                <!-- -->
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Data</th>
                                    <th>Situação</th>
                                    <th>Observação</th>
                                </tr>
                            </tfoot>
                    </table>
                </div>
                    </div>
                </div>
            </div>
        
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="modalEditarLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalEditarLabel">Edição de Pneu</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <form method="post" action="<?php echo base_url('frota/insertPneuIndividual') ?>">
                <input type="hidden" name="isedit" id="isedit" value="1"/>
                <input type="hidden" name="id_e" id="id_e">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <label>Tipo de Pneu</label>
                            <select class="js-example-basic-multiple" style="width:100%;" name="tipopneu_e" id="tipopneu_e" required>
                                <option selected value="">-- Selecionar --</option>
                                <?php foreach($tipospneu as $tipopneu){ ?>
                                    <option value="<?php echo $tipopneu['frota_pneu_id'] ?>"><?php echo $tipopneu['frota_pneu_marca'] . ' | Aro: ' . $tipopneu['frota_pneu_aro'] . ' | Banda: ' . $tipopneu['frota_pneu_banda'] ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div><br>
                    <div class="row">
                        <div class="col-md-12">
                            <label>Veículo vinculado</label>
                            <select class="js-example-basic-multiple" style="width:100%;" name="frota_e" id="frota_e" required>
                                <option selected value="">-- Selecionar --</option>
                                <option value="0">Nenhum</option>
                                <?php foreach($frota as $veiculo){ ?>
                                    <option value="<?php echo $veiculo['frota_id'] ?>">
                                        <?php 
                                            foreach($modelos as $modelo){
                                                if($modelo['frota_modelo_id'] == $veiculo['frota_modelo_id']){
                                                    foreach($marcas as $marca){
                                                        if($marca['frota_marca_id'] == $modelo['frota_modelo_marca_id']){
                                                            
                                                            echo $veiculo['frota_id'] . ' | ' . $marca['frota_marca_nome'] . ' ' . $modelo['frota_modelo_nome'];
                                                            
                                                            if(isset($veiculo['frota_cor']) && !empty($veiculo['frota_cor'])){
                                                                echo ' (' . $veiculo['frota_cor'] . ')';
                                                            }
                                                            
                                                            if(isset($veiculo['frota_placa']) && !empty($veiculo['frota_placa'])){
                                                                echo ' - ' . $veiculo['frota_placa'];
                                                            }
                                                            
                                                            if(isset($veiculo['frota_chassi']) && !empty($veiculo['frota_chassi'])){
                                                                echo ' - ' . $veiculo['frota_chassi'];
                                                            }
                                                            
                                                            if(isset($veiculo['frota_renavam']) && !empty($veiculo['frota_renavam'])){
                                                                echo ' - ' . $veiculo['frota_renavam'];
                                                            }
                                                            
                                                        }
                                                    }
                                                }
                                            }
                                        ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                    </div><br>
                    <div class="row">
                        <div class="col-md-12">
                            <label>Marcação do Pneu</label><br>
                            <input type="text" class="form-control" id="marcacao_e" name="marcacao_e" placeholder="Ex.: 225/55 R 17 97 W" required>
                        </div>
                    </div><br>
                    <div class="row">
                        <div class="col-md-12">
                            <label>Ativação</label>
                            <select class="js-example-basic-multiple" style="width:100%;" name="ativo_e" id="ativo_e" required>
                                <?php foreach($ativos as $ativo){ ?>
                                    <option value="<?php echo $ativo['ativo_id'] ?>"><?php echo $ativo['ativo_tipo'] ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
            
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" style="float: left">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
            
        </div>
    </div>
</div>

<div class="modal fade" id="modalExcluir" tabindex="-1" role="dialog" aria-labelledby="modalExcluirTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalCadastroLabel">Excluir Cadastro de Pneu</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="modal-body">
                <h4>Deseja realmente excluir o cadastro de pneu?</h4>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white; float: left" onclick="senha()">&nbsp&nbspSim&nbsp&nbsp</button>
                <button class="btn btn-danger" data-dismiss="modal">&nbsp&nbspNão&nbsp&nbsp</button>
                <br><br>
                <div class="row" id="formsenha" style="display: none">
                    <div class="col-md-12 text-center">
                        <form action="<?php echo base_url('frota/deletePneuIndividual') ?>" method="post">
                            <input type="hidden" name="idpneu" id="idpneu">
                            <label style="font-size: 16px">Confirme a senha</label><br>
                            <input class="form-control" type="password" name="senha" id="senha" placeholder="Digite a Senha" required style="width: 50%; margin-left: 25%"><br>
                            <button type="submit" class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">&nbsp&nbspConfirmar&nbsp&nbsp</button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<script>
    function registro(id, marcacao){
        $("#registro_individual_id").attr('value', id);
        $("#registro_individual_id_show").attr('value', "Registo do Pneu: " + id + " | " + marcacao);
    }
    function ver(id){
        var marcacao = "";
        <?php foreach($pneus as $pneu){ ?>
            if(id == '<?php echo $pneu['pneus_individual_id'] ?>'){
                marcacao = '<?php echo $pneu['pneus_individual_marcacao'] ?>';
            }
        <?php } ?>
        $("#marcacao_v").html(marcacao);
        
        var vinculo = "Nenhum";
        <?php foreach($pneus as $pneu){ ?>
            if(id == '<?php echo $pneu['pneus_individual_id'] ?>'){
                <?php foreach($frota as $veiculo){ ?>
                    if('<?php echo $veiculo['frota_id'] ?>' == '<?php echo $pneu['pneus_individual_frota_id'] ?>'){
                        <?php 
                            foreach($modelos as $modelo){ 
                                if($veiculo['frota_modelo_id'] == $modelo['frota_modelo_id']){
                                    foreach($marcas as $marca){
                                        if($marca['frota_marca_id'] == $modelo['frota_modelo_marca_id']){
                        ?>
                                            vinculo = "<?php echo $veiculo['frota_id'] ?>" + " | " + "<?php echo $marca['frota_marca_nome'] ?>" + " " + "<?php echo $modelo['frota_modelo_nome'] ?>";
                        <?php 
                                        }
                                    }
                                }
                            }
                        ?>
                    }
                <?php } ?>
                if('<?php echo $pneu['pneus_individual_ativo_id'] ?>' == '1'){
                    $("#ativo_v").html('Ativo');    
                }else{
                    $("#ativo_v").html('Inativo');
                }
            }
        <?php } ?>
        $("#vinculo_v").html(vinculo);
        
        var registros = "";
        <?php foreach($registrospneu as $regp) { ?>
            if(id == '<?php echo $regp['pneus_registro_individual_id'] ?>'){
                registros += 
                "<tr>" +
                    "<td>" + 
                        "<?php echo date("d/m/Y H:i", strtotime($regp['pneus_registro_data'])) ?>" +
                    "</td>" +
                    "<td>" + 
                        "<?php echo $regp['pneus_registro_situacao'] ?>" +
                    "</td>" +
                    "<td>" + 
                        "<?php echo $regp['pneus_registro_observacao'] ?>" +
                    "</td>" +
                "</tr>";
            }
        <?php } ?>
        if(registros.length == 0){
            registros = "<tr class='odd'><td valign='top' colspan='3' class='dataTables_empty'>Nada encontrado- refaça sua busca</td></tr>";
        }
        $("#registros_v").html(registros);
        
        
        $("#myTableRegistros").change();
    }
    function editar(id){
        <?php foreach($pneus as $pneu){ ?>
            if(id == '<?php echo $pneu['pneus_individual_id'] ?>'){
                $("#id_e").val(id);
                $("#marcacao_e").val('<?php echo $pneu['pneus_individual_marcacao'] ?>');
                $("#tipopneu_e").val(<?php echo $pneu['pneus_individual_tipopneu_id'] ?>).change();
                $("#frota_e").val(<?php echo $pneu['pneus_individual_frota_id'] ?>).change();
                $("#ativo_e").val(<?php echo $pneu['pneus_individual_ativo_id'] ?>).change();
            }
        <?php } ?>
    }
    function excluir(id){
        document.getElementById('idpneu').value = id;
    }
    function senha(){
        document.getElementById('formsenha').style.display = "block";
    }
</script>


<script>
    $(document).ready(function(){
        $('#myTableTipo').DataTable( {
            "order": [[ 0, "asc" ]],
            "language": {
                "lengthMenu": "Mostrando _MENU_ registros por página",
                "zeroRecords": "Nada encontrado- refaça sua busca",
                "info": "Mostrando _PAGE_ de _PAGES_",
                "infoEmpty": "Sem registros disponíves",
                "infoFiltered": "(filtrado _MAX_ dos registros totais)",
                "sSearch":       "Procurar:",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Próximo",
                }
            },
            "columns": [
                {"ID": "first", "orderable": true},
                {"Marcação": "second", "orderable": true},
                {"Tipo de Pneu": "third", "orderable": true},
                {"Vinculado à": "fourth", "orderable": true},
                {"Ação": "fifth", "orderable": false},
            ],
            initComplete: function () {
                this.api().columns([0]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([1]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([2]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([3]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
            }
        } );
        $('#myTableRegistros').DataTable( {
            "order": [[ 0, "asc" ]],
            "language": {
                "lengthMenu": "Mostrando _MENU_ registros por página",
                "zeroRecords": "Nada encontrado- refaça sua busca",
                "info": "Mostrando _PAGE_ de _PAGES_",
                "infoEmpty": "Sem registros disponíves",
                "infoFiltered": "(filtrado _MAX_ dos registros totais)",
                "sSearch":       "Procurar:",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Próximo",
                }
            },
            "columns": [
                {"Data": "first", "orderable": false},
                {"Situação": "second", "orderable": false},
                {"Observação": "third", "orderable": false}
            ],
            initComplete: function () {
                this.api().columns([0]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([1]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
            }
        } );
    });
</script>