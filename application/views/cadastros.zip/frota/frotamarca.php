<style>
    .tableFixHead          { overflow-y: auto; height: 600px; }
    .tableFixHead thead th { position: sticky; top: 0; }
    
    /* Just common table stuff. Really. */
    table  { border-collapse: collapse; width: 100%; }
    th, td { padding: 8px 16px; }
    th     { background:#eee; }
</style>

<br>
<section id="main-content">
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-6">
                <h3>Frota > Marcas</h3>
            </div>
            <div class="col-md-6" style="text-align: right;">
                <a data-toggle="modal" data-target="#modalCadastro" class="btn btn-primary" style="margin-top: 20px; border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">Nova Marca</a>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <div class="row" style="margin-left: 0px; margin-right: 0px">
            <div class="col-md-12" style="background-color: white;">
                <br>
                
                <?php if($erro == 1){ ?>
                <div class="row">
                    <div class="col-md-12 form-group">
                        <h4 class="text-danger">Erro: A senha informada estava incorreta, por favor tente novamente!</h4>
                    </div>
                </div>
                <?php } ?>
                
                <div class="tableFixHead">
                    <table id="myTableTipo" class="table table-hover table-bordered">
                          <thead>
                                <tr>
                                    <th>Nome da Marca</th>
                                    <th style="width: 180px">Ação</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                foreach($marcas as $marca){ 
			                        if($this->session->userdata('f_a') != 1 && $marca['frota_tipo_ativo_id'] != 2){    
                                ?>
                                <tr>
                                    <td><?php echo mb_strtoupper($marca['frota_marca_nome']) ?></td>
                                    <td>
                                        <?php if($this->session->userdata('f_v') == 1){ ?>
    			                        <a style="font-size: 12px" data-toggle="modal" data-target="#modalVer" onclick="ver(<?php echo $marca['frota_marca_id'] ?>)" class="btn btn-primary btn-modal-toggle"><i class="fas fa-eye"></i></a>
    			                        &nbsp;&nbsp;
    			                        <?php } ?>
    			                        <?php if($this->session->userdata('f_e') == 1){ ?>
    			                        <a data-toggle="modal" data-target="#modalEditar" onclick="editar(<?php echo $marca['frota_marca_id'] ?>)" class="btn btn-primary" style="font-size: 12px"><i class="fas fa-pencil-alt"></i></a>
    			                        &nbsp;&nbsp;
    			                        <?php } ?>
    			                        <?php if($this->session->userdata('f_d') == 1){ ?>
    			                        <a data-toggle="modal" data-target="#modalExcluir" class="btn btn-danger" style="font-size: 12px" onclick="excluir('<?php echo $marca['frota_marca_id'] ?>')"><i class="fas fa-trash"></i></i></a>
    			                        <?php } ?>
                                    </td>
                                </tr>
                                <?php }else if($this->session->userdata('f_a') == 1){ ?>
                                <tr <?php if($marca['frota_marca_ativo_id'] == 2){echo "style='background-color: #eaeaea'";} ?>>
                                    <td><?php echo mb_strtoupper($marca['frota_marca_nome']) ?></td>
                                    <td>
                                        <?php if($this->session->userdata('f_v') == 1){ ?>
    			                        <a style="font-size: 12px" data-toggle="modal" data-target="#modalVer" onclick="ver(<?php echo $marca['frota_marca_id'] ?>)" class="btn btn-primary btn-modal-toggle"><i class="fas fa-eye"></i></a>
    			                        &nbsp;&nbsp;
    			                        <?php } ?>
    			                        <?php if($this->session->userdata('f_e') == 1){ ?>
    			                        <a data-toggle="modal" data-target="#modalEditar" onclick="editar(<?php echo $marca['frota_marca_id'] ?>)" class="btn btn-primary" style="font-size: 12px"><i class="fas fa-pencil-alt"></i></a>
    			                        &nbsp;&nbsp;
    			                        <?php } ?>
    			                        <?php if($this->session->userdata('f_d') == 1){ ?>
    			                        <a data-toggle="modal" data-target="#modalExcluir" class="btn btn-danger" style="font-size: 12px" onclick="excluir('<?php echo $marca['frota_marca_id'] ?>')"><i class="fas fa-trash"></i></i></a>
    			                        <?php } ?>
                                    </td>
                                </tr>
                                <?php } } ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Nome da Marca</th>
                                    <th></th>
                                </tr>
                            </tfoot>
                    </table>
                </div>
                
                <br> 
            </div>
        </div>
        <br><br>
    </section>
</section>

<div class="modal fade" id="modalCadastro" tabindex="-1" role="dialog" aria-labelledby="modalCadastroLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalCadastroLabel">Cadastro de Marca</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <form method="post" action="<?php echo base_url('frota/insertMarca') ?>">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <label>Nome da Marca</label><br>
                            <input type="text" class="form-control" id="nome_c" name="nome_c" placeholder="Ex.: Scania" required>
                        </div>
                    </div>
                </div>
            
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" style="float: left">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Cadastrar</button>
                </div>
            </form>
            
        </div>
    </div>
</div>

<div class="modal fade" id="modalVer" tabindex="-1" role="dialog" aria-labelledby="modalVerLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalVerLabel">Visualizar Marca</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-8 form-group">
                        <label>Nome da Marca</label><br>
                        <label id="nome_v" style="font-size: 16px; color: black"></label>
                    </div>
                    <div class="col-md-4 form-group">
                        <label>Ativo</label><br>
                        <label id="ativo_v" style="font-size: 16px; color: black"></label>
                    </div>
                </div>
            </div>
        
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="modalEditarLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalEditarLabel">Edição de Marca</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <form method="post" action="<?php echo base_url('frota/insertMarca') ?>">
                <input type="hidden" name="isedit" id="isedit" value="1"/>
                <input type="hidden" name="id_e" id="id_e">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-8 form-group">
                            <label>Nome da Marca</label><br>
                            <input type="text" class="form-control" id="nome_e" name="nome_e" placeholder="Ex.: Truck" required>
                        </div>
                        <div class="col-md-4 form-group">
                            <label>Ativação</label>
                            <select class="js-example-basic-multiple" style="width:100%;" name="ativo_e" id="ativo_e" required>
                                <?php foreach($ativos as $ativo){ ?>
                                    <option value="<?php echo $ativo['ativo_id'] ?>"><?php echo $ativo['ativo_tipo'] ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
            
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" style="float: left">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
            
        </div>
    </div>
</div>

<div class="modal fade" id="modalExcluir" tabindex="-1" role="dialog" aria-labelledby="modalExcluirTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalCadastroLabel">Excluir Marca</h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="modal-body">
                <h4>Deseja realmente excluir a marca?</h4>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white; float: left" onclick="senha()">&nbsp&nbspSim&nbsp&nbsp</button>
                <button class="btn btn-danger" data-dismiss="modal">&nbsp&nbspNão&nbsp&nbsp</button>
                <br><br>
                <div class="row" id="formsenha" style="display: none">
                    <div class="col-md-12 text-center">
                        <form action="<?php echo base_url('frota/deleteMarca') ?>" method="post">
                            <input type="hidden" name="idtipofrota" id="marca">
                            <label style="font-size: 16px">Confirme a senha</label><br>
                            <input class="form-control" type="password" name="senha" id="senha" placeholder="Digite a Senha" required style="width: 50%; margin-left: 25%"><br>
                            <button type="submit" class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">&nbsp&nbspConfirmar&nbsp&nbsp</button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<script>
    function ver(id){
        
        var dados = {
            'frota_marca_id': id
        };
                
        $.ajax({
            url : '<?php echo base_url('frota/getMarcaById') ?>',
            type : "POST",
            dataType : "json",
            data : dados,
            success : function(response) {
                res = response[0];
                $("#nome_v").html(res.frota_marca_nome);
                
                if(res.frota_marca_ativo_id == 2){
                    $("#ativo_v").html('Inativo');
                }else{
                    $("#ativo_v").html('Ativo');
                }
            },
            error : function(xhr, status, error) {
                alert(status + " " + error + " " + xhr);
            }
        });
    }
    function editar(id){
        var dados = {
            'frota_marca_id': id
        };
                
        $.ajax({
            url : '<?php echo base_url('frota/getMarcaById') ?>',
            type : "POST",
            dataType : "json",
            data : dados,
            success : function(response) {
                res = response[0];
                $("#id_e").val(res.frota_marca_id);
                $("#nome_e").val(res.frota_marca_nome);
                $("#ativo_e").val(res.frota_marca_ativo_id).change();
            },
            error : function(xhr, status, error) {
                alert(status + " " + error + " " + xhr);
            }
        });
    }
</script>

<script>
    function excluir(id){
        document.getElementById('idmarca').value = id;
    }
    function senha(){
        document.getElementById('formsenha').style.display = "block";
    }
</script>

<script>
    $(document).ready(function(){
        $('#myTableTipo').DataTable( {
            "order": [[ 0, "asc" ]],
            "language": {
                "lengthMenu": "Mostrando _MENU_ registros por página",
                "zeroRecords": "Nada encontrado- refaça sua busca",
                "info": "Mostrando _PAGE_ de _PAGES_",
                "infoEmpty": "Sem registros disponíves",
                "infoFiltered": "(filtrado _MAX_ dos registros totais)",
                "sSearch":       "Procurar:",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Próximo",
                }
            },
            "columns": [
                {"Nome da Marca": "first", "orderable": true},
                {"Ação": "second", "orderable": false},
            ],
            initComplete: function () {
                this.api().columns([0]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
            }
        } );
    });
</script>