<style>
    .tableFixHead          { overflow-y: auto; height: 450px; }
    .tableFixHead thead th { position: sticky; top: 0; }
    
    /* Just common table stuff. Really. */
    table  { border-collapse: collapse; width: 100%; }
    th, td { padding: 8px 16px; }
    th     { background:#eee; }
    
    .blue_btn{
        border: 1px solid #4ECDC4;
        background-color: #4ECDC4;
        padding: 10px 15px;
        color: white;
    }
    .red_btn{
        border: 1px solid #FF1111;
        background-color: #FF1111;
        padding: 10px 15px;
        color: white;
    }
</style>

<br>
<section id="main-content">
    
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-6">
                <h3>Usuários > Listagem</h3>
            </div>
            <div class="col-md-6" style="text-align: right;">
                <a href="<?php echo base_url('usuario/cadastro'); ?>" class="btn btn-success" style='margin-top: 20px; border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white'>Novo Usuário</a>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <div class="row" style="margin-left: 0px; margin-right: 0px">
            <div class="col-md-12" style="background-color: white;">
                <br>
                
                <?php if($erro != null){ ?>
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="text-danger">Erro: A senha informada estava incorreta, por favor tente novamente!</h3>
                    </div>
                </div>
                <br>
                <?php } ?>
                
                <div class="tableFixHead">
                    <table id="myTableUsuario" class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>CPF</th>
                                <th>Cidade</th>
                                <th>Estado</th>
                                <th style="width: 180px">Ação</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($users as $user){
                                if($user['usuario_id'] != 1){
                                    if($this->session->userdata('u_a') != 1 && $user['usuario_ativo_id'] != 2){
                            ?>
                                <tr>
                                    <td><?php echo $user['usuario_nome']; ?></td>
                                    <td>
                                        <?php
				                            $cpf = substr($user['usuario_cpf'], 0, 3).".".substr($user['usuario_cpf'], 3, 3).".".substr($user['usuario_cpf'], 6, 3)."-".substr($user['usuario_cpf'], 9);
				                            echo $cpf; 
				                        ?>
                                    </td>
                                    <td><?php echo $user['usuario_cidade']; ?></td>
                                    <td><?php echo $user['usuario_estado']; ?></td>
                                    <td>
                                        <?php if($this->session->userdata('u_v') == 1){ ?>
                                        <a style="font-size: 12px" data-toggle="modal" data-target="#modalUsuario" data-usuario="<?php echo $user['usuario_id'] ?>" class="btn btn-primary btn-modal-toggle"><i class="fas fa-eye"></i></a>
                                        &nbsp&nbsp
                                        <?php } ?>
                                        <?php if($this->session->userdata('u_e') == 1){ ?>
                                        <a style="font-size: 12px" href="<?php echo base_url('usuario/cadastro?edicao_id=' . $user['usuario_id']) ?>" class="btn btn-primary" ><i class="fas fa-pencil-alt"></i></a>
                                        &nbsp&nbsp
                                        <?php } ?>
                                        <?php if($this->session->userdata('u_d') == 1){ ?>
                                        <a data-toggle="modal" data-target="#modalExcluir" style="font-size: 12px" class="btn btn-danger" onclick="setaExcluir('<?php echo $user['usuario_id'] ?>')"><i class="fas fa-trash"></i></a>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php }else if($this->session->userdata('u_a') == 1){ ?>
                                <tr <?php if($user['usuario_ativo_id'] == 2){echo "style='background-color: #eaeaea'";} ?>>
                                    <td><?php echo $user['usuario_nome']; ?></td>
                                    <td>
                                        <?php
				                            $cpf = substr($user['usuario_cpf'], 0, 3).".".substr($user['usuario_cpf'], 3, 3).".".substr($user['usuario_cpf'], 6, 3)."-".substr($user['usuario_cpf'], 9);
				                            echo $cpf; 
				                        ?>
                                    </td>
                                    <td><?php echo $user['usuario_cidade']; ?></td>
                                    <td><?php echo $user['usuario_estado']; ?></td>
                                    <td>
                                        <?php if($this->session->userdata('u_v') == 1){ ?>
                                        <a style="font-size: 12px" data-toggle="modal" data-target="#modalUsuario" data-usuario="<?php echo $user['usuario_id'] ?>" class="btn btn-primary btn-modal-toggle"><i class="fas fa-eye"></i></a>
                                        &nbsp&nbsp
                                        <?php } ?>
                                        <?php if($this->session->userdata('u_e') == 1){ ?>
                                        <a style="font-size: 12px" href="<?php echo base_url('usuario/cadastro?edicao_id=' . $user['usuario_id']) ?>" class="btn btn-primary" ><i class="fas fa-pencil-alt"></i></a>
                                        &nbsp&nbsp
                                        <?php } ?>
                                        <?php if($this->session->userdata('u_d') == 1){ ?>
                                        <a data-toggle="modal" data-target="#modalExcluir" style="font-size: 12px" class="btn btn-danger" onclick="setaExcluir('<?php echo $user['usuario_id'] ?>')"><i class="fas fa-trash"></i></a>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php } } }?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Nome</th>
                                <th>CPF</th>
                                <th>Cidade</th>
                                <th>Estado</th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <br>
            </div>
        </div>
        <br><br>
    </section>
</section>

<div class="modal fade" id="modalExcluir" tabindex="-1" role="dialog" aria-labelledby="modalExcluirTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Mensagem do Sistema</h5>
            </div>
            <div class="modal-body">
                <h4>Deseja realmente excluir o usuário?</h4>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white; float: left" onclick="senha()">&nbsp&nbspSim&nbsp&nbsp</button>
                <button class="btn btn-danger" data-dismiss="modal">&nbsp&nbspNão&nbsp&nbsp</button>
                <br><br>
                <div class="row" id="formsenha" style="display: none">
                    <div class="col-md-12 text-center">
                        <form action="<?php echo base_url('usuario/deleteUsuario') ?>" method="post">
                            <input type="hidden" name="iduser" id="iduser">
                            <label style="font-size: 16px">Confirme a senha</label><br>
                            <input class="form-control" type="password" name="senha" id="senha" placeholder="Digite a Senha" required style="width: 50%; margin-left: 25%"><br>
                            <button type="submit" class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">&nbsp&nbspConfirmar&nbsp&nbsp</button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<!-- ModalUsuario -->
<div class="modal fade" id="modalUsuario" tabindex="-1" role="dialog" aria-labelledby="modalUsuario" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header" style="padding: 3px">
                <div class="row">
                    <div class="col-md-12 text-right">
                        <button type="button" class="close" data-dismiss="modal" style="margin-right: 5px">&times;</button>
                    </div>
                </div>
            </div>
            
            <div class="modal-body" style="background-color: #eaeaea; padding-bottom: 0px">
                <ul class="nav nav-tabs" id="myTab" role="tablist" style="background-color: #eaeaea">
                    <li class="nav-item">
                        <a class="nav-link" style="background-color: white; cursor: pointer" id="aDados" onclick="change(1)">Dados</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="cursor: pointer" id="aDias" onclick="change(2)">Dias</a>
                    </li>
                </ul>
                <div class="row" id="divDados" style="display: block;">
                    <div class="col-md-12" style="background-color: white">
                        <br>
                        
                        <div class="row form-group">
                            <div class="col-md-9">
                                <label>Nome: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-nome"></label>
                            </div>
                            <div class="col-md-3 text-right" id="ativo">
                                
                            </div>
                        </div>
                        
                        <div class="row form-group">
                            <div class="col-md-4">
                                <label>CPF: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-cpf"></label>
                            </div>
                            <div class="col-md-4">
                                <label>RG: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-rg"></label>
                            </div>
                            <div class="col-md-4">
                                <label>Data de Nascimento: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-dt"></label>
                            </div>
                        </div>
                        
                        <div class="row form-group">
                            <div class="col-md-4">
                                <label>Função: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-funcao" name="text-funcao"></label>
                            </div>
                            <div class="col-md-4">
                                <label>Telefone: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-telefone"></label>
                            </div>
                            <div class="col-md-4">
                                <label>Celular: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-celular"></label>
                            </div>
                        </div>
                        
                        <div class="row form-group">
                            <div class="col-md-12">
                                <label>Endereco: </label>
                                <br>
                                <label style="color: black; font-size: 16px" id="text-endereco"></label>
                            </div>    
                        </div>

                        <br>
                    </div>
                </div>
                <div class="row" id="divDias" style="display: none">
                    <div class="col-md-12" style="background-color: white">
                        <br>

                        <div class="row">
                            <div class="col-md-12">
                                <label>Dias e Horário de Acesso:</label>
                                <br><br>
                                <label style="color: black; font-size: 16px" id="text-trabalho"></label>
                            </div>
                        </div>

                        <br>
                    </div>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script>
    function setaExcluir(id){
        document.getElementById('iduser').value = id;
    }
    function senha(){
        document.getElementById('formsenha').style.display = "block";
    }
</script>

<script>
    function change(value){
        if(value == 1){
            document.getElementById('aDados').style = "background-color: white; cursor: pointer";
            document.getElementById('aDias').style = "background-color: #eaeaea; cursor: pointer";
            document.getElementById('divDados').style.display = "block";
            document.getElementById('divDias').style.display = "none";
        }else{
            document.getElementById('aDias').style = "background-color: white; cursor: pointer";
            document.getElementById('aDados').style = "background-color: #eaeaea; cursor: pointer";
            document.getElementById('divDias').style.display = "block";
            document.getElementById('divDados').style.display = "none";
        }
    }
</script>

<script>
    $(document).ready(function(){
        
        $('.btn-modal-toggle').on('click', function(){
            $("#modalUsuario").modal('hide');
            var button = $(this);
            var recipient = button.data('usuario');
        
            var dados = {
                    'usuario_id': recipient
                };
            $.ajax({
                url : '<?php echo base_url('usuario/getUsuarioById') ?>',
                type : "POST",
                dataType : "json",
                data : dados,
                success : function(response) {
                    res = response[0];
                
                    $("#text-cpf").unmask();
                    $("#text-cpf").html(res.usuario_cpf);
                    $("#text-cpf").mask("000.000.000-00");
                    
                    $('#text-rg').html(res.usuario_rg);
                    $("#text-nome").html(res.usuario_nome);
                    
                    var ex = res.usuario_nascimento.split('-');
                    var dt = ex[2]+"/"+ex[1]+"/"+ex[0];
                    $('#text-dt').html(dt);
                    
                    $("#text-telefone").unmask();
                    $("#text-telefone").html(res.usuario_telefone);
                    if(res.usuario_telefone.length == 10){$("#text-telefone").mask("(00) 0000-0000");}
                    else if(res.usuario_telefone.length == 11){$("#text-telefone").mask("(00) 0 0000-0000");}
                    
                    $("#text-celular").unmask();
                    if(res.usuario_celular != null && res.usuario_celular != ""){
                        $("#text-celular").html(res.usuario_celular);
                    }else{
                        $("#text-celular").html("Não possui");
                    }
                    if(res.usuario_celular.length == 10){$("#text-celular").mask("(00) 0000-0000");}
                    else if(res.usuario_celular.length == 11){$("#text-celular").mask("(00) 0 0000-0000");}
                
                    var atv;
                    if(res.usuario_ativo_id == 1){
                        atv = "<button disabled class='btn btn-success' style=1font-size: 20px; float: right'>Ativo</button>";
                    }else if(res.usuario_ativo_id == 2){
                        atv = "<button disabled class='btn btn-danger' style=1font-size: 20px; float: right'>Inativo</button>";
                    }
                    $('#ativo').html(atv);
                
                    var endereco = res.usuario_endereco + ", nº " + res.usuario_numero + ", " + res.usuario_cep + ", " + res.usuario_cidade + " - " + res.usuario_estado;
                    $("#text-endereco").html(endereco);
                
                    if(res.usuario_trabalho != null && res.usuario_trabalho != ""){
                        var trabalhoTexto = "";
                        var trabalho = res.usuario_trabalho;
                        var trabalhoSplitPipe = trabalho.split('|');
                    
                        for(var i in trabalhoSplitPipe) {
                            if(trabalhoTexto.length > 0){trabalhoTexto += "<br>";}
                            var trabalhoDia = trabalhoSplitPipe[i];
                            var diaReferente = trabalhoDia.split('-')[0];
                            var hrEntrada = trabalhoDia.split('-')[1];
                            var hrSaida = trabalhoDia.split('-')[2];
                            trabalhoTexto += diaReferente.toUpperCase() + ": " + hrEntrada + " às " + hrSaida;
                        }
                        $("#text-trabalho").html(trabalhoTexto);
                    }else{
                        $("#text-trabalho").html("Não possui");
                    }
                
                    var dadosFuncao = {
                        'usuario_funcao_id': res.usuario_funcao_id
                    }
                
                    $.ajax({
                        url : '<?php echo base_url('usuario/getFuncaoById') ?>',
                        type : "POST",
                        dataType : "json",
                        data : dadosFuncao,
                        success : function(response) {
                            res = response[0];
                            $("#text-funcao").html(res.funcao_nome);
                            
                            //END OF QUERY
                            $("#modalUsuario").modal('show');
                        },
                        error : function(xhr, status, error) {
                            var err = eval("(" + xhr.responseText + ")");
                        alert(status + " " + error + " " + err);
                        }
                    });
                },
                error : function(xhr, status, error) {
                    var err = eval("(" + xhr.responseText + ")");
                    alert(status + " " + error + " " + err);
                }
            });
        });
        $('#modalUsuario').on('shown.bs.modal', function (e) {
            /*
            var button = $(e.relatedTarget);
            var recipient = button.data('usuario');
        
            var dados = {
                    'usuario_id': recipient
                };
            $.ajax({
                url : '<?php // echo base_url('usuario/getUsuarioById') ?>',
                type : "POST",
                dataType : "json",
                data : dados,
                success : function(response) {
                    res = response[0];
                
                    $("#text-cpf").unmask();
                    $("#text-cpf").html(res.usuario_cpf);
                    $("#text-cpf").mask("000.000.000-00");
                    
                    $("#text-nome").html(res.usuario_nome);
                    
                    $("#text-telefone").unmask();
                    $("#text-telefone").html(res.usuario_telefone);
                    if(res.usuario_telefone.length == 10){$("#text-telefone").mask("(00) 0000-0000");}
                    else if(res.usuario_telefone.length == 11){$("#text-telefone").mask("(00) 0 0000-0000");}
                
                    var endereco = res.usuario_endereco + ", nº " + res.usuario_numero + ", " + res.usuario_cidade + " - " + res.usuario_estado;
                    $("#text-endereco").html(endereco);
                
                    var trabalhoTexto = "";
                    var trabalho = res.usuario_trabalho;
                    var trabalhoSplitPipe = trabalho.split('|');
                
                    for(var i in trabalhoSplitPipe) {
                        if(trabalhoTexto.length > 0){trabalhoTexto += "<br>";}
                        var trabalhoDia = trabalhoSplitPipe[i];
                        var diaReferente = trabalhoDia.split('-')[0];
                        var hrEntrada = trabalhoDia.split('-')[1];
                        var hrSaida = trabalhoDia.split('-')[2];
                        trabalhoTexto += diaReferente.toUpperCase() + ": " + hrEntrada + " às " + hrSaida;
                    }
                    $("#text-trabalho").html(trabalhoTexto);
                
                    var dadosFuncao = {
                        'usuario_funcao_id': res.usuario_funcao_id
                    }
                
                    $.ajax({
                        url : '<?php // echo base_url('usuario/getFuncaoById') ?>',
                        type : "POST",
                        dataType : "json",
                        data : dadosFuncao,
                        success : function(response) {
                            res = response[0];
                            $("#text-funcao").html(res.funcao_nome);
                        },
                        error : function(xhr, status, error) {
                            var err = eval("(" + xhr.responseText + ")");
                        alert(status + " " + error + " " + err);
                        }
                    });
                },
                error : function(xhr, status, error) {
                    var err = eval("(" + xhr.responseText + ")");
                    alert(status + " " + error + " " + err);
                }
            });
            */
        });
        
        $('#myTableUsuario').DataTable( {
            "order": [[ 0, "asc" ]],
            "language": {
                "lengthMenu": "Mostrando _MENU_ registros por página",
                "zeroRecords": "Nada encontrado- refaça sua busca",
                "info": "Mostrando _PAGE_ de _PAGES_",
                "infoEmpty": "Sem registros disponíves",
                "infoFiltered": "(filtrado _MAX_ dos registros totais)",
                "sSearch":       "Procurar:",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Próximo",
                }
            },
            "columns": [
                {"Nome": "first", "orderable": true},
                {"CPF": "second", "orderable": true},
                {"Cidade": "third", "orderable": true},
                {"Estado": "fourth", "orderable": true},
                {"Ação": "fifth", "orderable": false},
            ],
            initComplete: function () {
                this.api().columns([0]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([1]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([2]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todas</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([3]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
            }
        } );
    });
</script>