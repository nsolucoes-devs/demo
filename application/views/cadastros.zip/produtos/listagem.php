
<style>
    .tableFixHead          { overflow-y: auto; height: 600px; }
    .tableFixHead thead th { position: sticky; top: 0; }
    
    /* Just common table stuff. Really. */
    table  { border-collapse: collapse; width: 100%; }
    th, td { padding: 8px 16px; }
    th     { background:#eee; }
</style>

<br>
<section id="main-content">
    <section class="wrapper">
        
        <div class="row">
            <div class="col-md-6">
                <h3>Produtos > Listagem</h3>
            </div>
            <div class="col-md-6" style="text-align: right;">
                <a href="<?php echo base_url('produtos/cadastro'); ?>" class="btn btn-success" style='margin-top: 20px; border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white'>Novo Produto</a>
            </div>
        </div>
        
        <hr style="height: 1px; background-color: #ccc; border: none;">
        
        <div class="row" style="margin-left: 0px; margin-right: 0px">
            <div class="col-md-12" style="background-color: white;">
               <br>
               
                <div class="tableFixHead">
                    <table id="myTableProdutos" class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Modelo</th>
                                <th>Fabricante</th>
                                <th>Quantidade</th>
                                <th style="width: 180px">Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($produtos as $produto){ 
                                if($produto['produto_ativo_id'] != 2){
                            ?>
                            <tr>
                                <td><?php echo $produto['produto_nome'] ?></td>
                                <td><?php echo $produto['produto_modelo'] ?></td>
                                <td><?php echo $produto['produto_fabricante'] ?></td>
                                <td><?php echo $produto['produto_quantidade'] ?></td>
                                <td>
                                    <a style="font-size: 12px" data-toggle="modal" data-target="#modalProduto" data-produto="" class="btn btn-primary btn-modal-toggle"><i class="fas fa-eye"></i></a>
                                    <a style="font-size: 12px" href="<?php echo base_url('produtos/') . 'cadastro?edicao_id=' . $produto['produto_id'] ?>" class="btn btn-primary" ><i class="fas fa-pencil-alt"></i></a>
                                    <a data-toggle="modal" data-target="#modalExcluir" style="font-size: 12px" class="btn btn-danger" onclick="setaExcluir(<?php echo $produto['produto_id'] ?>)"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php }
                                }
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Nome</th>
                                <th>Modelo</th>
                                <th>Fabricante</th>
                                <th>Quantidade</th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <br><br>
            </div>
        </div>
        
    </section>
</section>

<!-- modalExcluir -->
<div class="modal fade" id="modalExcluir" tabindex="-1" role="dialog" aria-labelledby="modalExcluirTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Mensagem do Sistema</h5>
            </div>
            <div class="modal-body">
                <h4>Deseja realmente excluir o produto?</h4>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white; float: left" onclick="senha()">&nbsp&nbspSim&nbsp&nbsp</button>
                <button class="btn btn-danger" data-dismiss="modal">&nbsp&nbspNão&nbsp&nbsp</button>
                <br><br>
                <div class="row" id="formsenha" style="display: none">
                    <div class="col-md-12 text-center">
                        <form action="<?php echo base_url('produtos/deleteProduto') ?>" method="post">
                            <input type="hidden" name="idproduto" id="idproduto">
                            <label style="font-size: 16px">Confirme a senha</label><br>
                            <input class="form-control" type="password" name="senha" id="senha" placeholder="Digite a Senha" required style="width: 50%; margin-left: 25%"><br>
                            <button type="submit" class="btn btn-primary" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white">&nbsp&nbspConfirmar&nbsp&nbsp</button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<!-- ModalProduto -->

<div class="modal fade" id="modalProduto" tabindex="-1" role="dialog" aria-labelledby="modalVerLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="modal-title" id="modalVerLabel">Visualização do <p id="linha_v" style="display:inline; padding:0px; margin:0px;">produto</p> </h4>
                    </div>
                    <div class="col-md-2 text-right">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-8 form-group">
                        <label style="font-size: 19px;">Produto: </label><br>&nbsp;&nbsp;
                        <label id="nome_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">Código: </label><br>&nbsp;&nbsp;
                        <label id="codigo_p" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <label style="font-size: 19px;">Situação: <br>&nbsp;&nbsp;
                        <label id="status_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-4 form-group">
                        <label style="font-size: 19px;">Modelo: </label><br>&nbsp;&nbsp;
                        <label id="modelo_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-4 form-group">
                        <label style="font-size: 19px;">Fabricante: </label><br>&nbsp;&nbsp;
                        <label id="fabricante_p" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <label style="font-size: 19px;">Preço de custo: <br>&nbsp;&nbsp;
                        <label id="preco_custo_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-4 form-group">
                        <label style="font-size: 19px;">Preço de venda: <br>&nbsp;&nbsp;
                        <label id="preco_venda_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-4 form-group">
                        <label style="font-size: 19px;">Fornecedor: <br>&nbsp;&nbsp;
                        <label id="fornecedor_p" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">Comprimento: </label><br>&nbsp;&nbsp;
                        <label id="comprimento_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">Largura: </label><br>&nbsp;&nbsp;
                        <label id="largura_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">Altura: </label><br>&nbsp;&nbsp;
                        <label id="altura_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">Peso: </label><br>&nbsp;&nbsp;
                        <label id="peso_p" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">SKU: <br>&nbsp;&nbsp;
                        <label id="sku_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">NCM: <br>&nbsp;&nbsp;
                        <label id="ncm_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">CEST: <br>&nbsp;&nbsp;
                        <label id="cest_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">UPC: <br>&nbsp;&nbsp;
                        <label id="upc_p" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">EAN: <br>&nbsp;&nbsp;
                        <label id="ean_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">JAN: <br>&nbsp;&nbsp;
                        <label id="jan_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">ISBN: <br>&nbsp;&nbsp;
                        <label id="isbn_p" style="font-size: 16px; color: black">--</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <label style="font-size: 19px;">MPN: <br>&nbsp;&nbsp;
                        <label id="mpn_p" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12 form-group">
                        <label style="font-size: 19px;">Detalhes: <br>&nbsp;&nbsp;
                        <label id="detalhes_p" style="font-size: 16px; color: black">--</label>
                    </div>
                </div>
            </div>
        
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
            </div>

        </div>
    </div>
</div>
    

<script>
    function setaExcluir(id){
        document.getElementById('idproduto').value = id;
    }
    function senha(){
        document.getElementById('formsenha').style.display = "block";
    }
</script>

<script>
    function change(value){
        if(value == 1){
            document.getElementById('aDados').style = "background-color: white; cursor: pointer";
            document.getElementById('aDias').style = "background-color: #eaeaea; cursor: pointer";
            document.getElementById('divDados').style.display = "block";
            document.getElementById('divDias').style.display = "none";
        }else{
            document.getElementById('aDias').style = "background-color: white; cursor: pointer";
            document.getElementById('aDados').style = "background-color: #eaeaea; cursor: pointer";
            document.getElementById('divDias').style.display = "block";
            document.getElementById('divDados').style.display = "none";
        }
    }
</script>

<script>
    $(document).ready(function(){
        
        $('#myTableProdutos').DataTable( {
            "order": [[ 0, "asc" ]],
            "language": {
                "lengthMenu": "Mostrando _MENU_ registros por página",
                "zeroRecords": "Nada encontrado- refaça sua busca",
                "info": "Mostrando _PAGE_ de _PAGES_",
                "infoEmpty": "Sem registros disponíves",
                "infoFiltered": "(filtrado _MAX_ dos registros totais)",
                "sSearch":       "Procurar:",
                "paginate": {
                    "previous": "Anterior",
                    "next": "Próximo",
                }
            },
            "columns": [
                {"Nome": "first", "orderable": true},
                {"CPF": "second", "orderable": true},
                {"Cidade": "third", "orderable": true},
                {"Estado": "fourth", "orderable": true},
                {"Ação": "fifth", "orderable": false},
            ],
            initComplete: function () {
                this.api().columns([0]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([1]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([2]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todas</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
                this.api().columns([3]).every( function () {
                    var column = this;
                    var select = $('<select class="js-example-basic-multiple" style="width: 100%"><option value="">Todos</option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );
                             column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                                } );
       
                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
            }
        } );
    });
</script>