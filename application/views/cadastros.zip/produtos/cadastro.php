<style>
    .inline{
        display: inline;
    }
    .disabled-field{}
</style>

<?php
    $iphone = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
    $ipad = strpos($_SERVER['HTTP_USER_AGENT'],"iPad");
    $android = strpos($_SERVER['HTTP_USER_AGENT'],"Android");
    $palmpre = strpos($_SERVER['HTTP_USER_AGENT'],"webOS");
    $berry = strpos($_SERVER['HTTP_USER_AGENT'],"BlackBerry");
    $ipod = strpos($_SERVER['HTTP_USER_AGENT'],"iPod");
    $symbian =  strpos($_SERVER['HTTP_USER_AGENT'],"Symbian");
    $auxfooter = 0;
    if ($iphone || $ipad || $android || $palmpre || $ipod || $berry || $symbian == true) {
        $phone = 1;
    } else {
        $phone = 0;
    }
?>

<script>
    $(document).ready(function(){
        
        $('.js-example-basic-multiple').select2({theme: "bootstrap"});
        
        function autoFillByID(id){
            var dados = {
                'produto_id': id
            };
        
            $.ajax({
                url : '<?php echo base_url('produtos/getProdutoByID') ?>',
                type : 'POST',
                dataType : 'json',
                data : dados,
                success : function(response) {
                    res = response[0];
                    treatAutofillData(res);
                },
                error : function(xhr, status, error) {
                    alert(status + " " + error + " " + xhr);
                }
            });
        
            $('.disabled-field').removeAttr('disabled');
        }
        
        <?php 
            if(isset($_GET['edicao_id'])){
                $edicao_id = $_GET['edicao_id'];
        
                echo "
                    autoFillByID(". $edicao_id ."); 
                ";
        
            }
        ?>
        
        
        function treatAutofillData(data){
            
            $("#id").val(data.produto_id);
            $("#nome").val(data.produto_nome);
            $("#codigo").val(data.produto_codigo);
            $("#preco_custo").val(data.produto_preco_custo);
            $("#preco_venda").val(data.produto_preco_venda);
            $("#fabricante").val(data.produto_fabricante);
            $("#fornecedor").val(data.produto_fornecedor_cnpj);
            $("#detalhes").val(data.produto_detalhes);
            $("#modelo").val(data.produto_modelo);
            $("#quantidade").val(data.produto_quantidade);
            $("#ativo").val(data.produto_ativo_id);
            //IDENTIFICADORES
            $("#sku").val(data.produto_sku);
            $("#ncm").val(data.produto_ncm);
            $("#cest").val(data.produto_cest);
            $("#upc").val(data.produto_upc);
            $("#ean").val(data.produto_ean);
            $("#jan").val(data.produto_jan);
            $("#isbn").val(data.produto_isbn);
            $("#mpn").val(data.produto_mpn);
            //MEDIDAS
            $("#un_medida").val(data.produto_un_medida);
            $("#un_peso").val(data.produto_un_peso);
            $("#comprimento").val(data.produto_comprimento);
            $("#largura").val(data.produto_largura);
            $("#altura").val(data.produto_altura);
            $("#peso").val(data.produto_peso);
            
        }
        
        $("#btn-clear").click(function(){
            window.location.href = '<?php echo base_url('produtos/cadastro') ?>';
            /*
            $("input").each(function(){
                $(this).val(""); 
                $(this).prop("disabled", true);
            });
            $("select").each(function(){
                $(this).val("").change();
                $(this).prop("disabled", true);
            });
            $("input[type=checkbox]").each(function(){
               $(this).prop("checked", false); 
            });
            $("button").prop("disabled", true);
            
            $("#btn-save").val("Salvar");
            $("#cpf").prop("disabled", false);
            */
        });
           
    });             
</script>

<br>
<section id="main-content" style="margin-bottom: 30px">
    <section class="wrapper">
        <form action="<?php echo base_url('produtos/insertProduto') ?>" method="post">
        
            <div class="row">
                <div class="col-md-12">
                    <h3>Produtos > <?php if(isset($_GET['edicao_id'])){echo 'Edição de Produto';}else{echo 'Cadastro de Produto';} ?></h3>
                </div>
            </div>
            
            <hr style="height: 1px; background-color: #ccc; border: none;">
            
            <div class="row" style="margin-left: 0px; margin-right: 0px">
            
                <div class="col-md-12" style="background-color:white;">
                    <br><br>
                
                    <input type="hidden" id="id" name="id" value=""/>
                    
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="nome">Nome</label><br>
                            <input id="nome" name="nome" type="text" class="form-control" placeholder="Nome do Produto" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="codigo">Código do Produto</label>
                            <input id="codigo" name="codigo" type="text" class="form-control" placeholder="Código do Produto" required>
                        </div>
                    
                        <?php if(isset($_GET['edicao_id'])){ ?>
                        <div class="col-md-3 form-group">
                            <label for="ativo">Ativo</label><br>
                            <select class="js-example-basic-multiple" style="width:100%;" name="ativo" id="ativo" required>
                                <option id="ativo-placeholder" selected disabled value="">-- Selecionar --</option>
                                <?php  foreach($ativos as $ativo){
                                    if(isset($_GET['edicao_id'])){
                                        if($this->session->userdata('u_a') == 1){
                                            echo '<option value="'.$ativo['ativo_id'].'">'.$ativo['ativo_tipo'].'</option>';
                                        }else{
                                            if($ativo['ativo_id'] == 2){
                                                echo '<option value="'.$ativo['ativo_id'].'">'.$ativo['ativo_tipo'].'</option>';
                                            }
                                        }
                                    }else if($ativo['ativo_id'] != 2){
                                        echo '<option value="'.$ativo['ativo_id'].'">'.$ativo['ativo_tipo'].'</option>';
                                    }
                                } ?>
                            </select>
                        </div>
                        <?php } else { ?>
                        <div class="col-md-3 form-group" style="display:none;">
                            <label for="ativo">Ativo</label><br>
                            <select class="js-example-basic-multiple" style="width:100%;" name="ativo" id="ativo" required>
                                <option id="ativo-placeholder" selected value="1">Ativo</option>
                            </select>
                        </div>
                        <?php } ?>
                    </div>

                    <div class="row">
                        <div class="col-md-5 form-group">
                            <label for="modelo">Modelo</label><br>
                            <input id="modelo" name="modelo" type="text" class="form-control disabled-field" placeholder="Modelo do Produto" required>
                        </div>
                        <div class="col-md-5 form-group">
                            <label for="fabricante">Fabricante</label><br>
                            <input id="fabricante" name="fabricante" type="text" class="form-control" placeholder="Fabricante do Produto" required>
                        </div>
                        <div class="col-md-2 form-group">
                            <label for="quantidade">Quantidade Inicial</label><br>
                            <input id="quantidade" name="quantidade" type="number" class="form-control" value="0" placeholder="0000" required>
                        </div>
                    </div>

                    <br>
                    <hr style="height: 1px; background-color: #ccc; border: none;">
                    <br>
                    
                    <div class="row">
                        <div class="col-md-3 form-group">
                            <label for="preco_custo">Preço de Custo (R$)</label><br>
                            <input id="precocusto" name="precocusto" type="text" class="form-control" placeholder="R$00,00" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="preco_venda">Preço de Venda (R$)</label><br>
                            <input id="precovenda" name="precovenda" type="text" class="form-control" placeholder="R$00,00" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="fornecedor">Fornecedor</label><br>
                            <select class="js-example-basic-multiple" style="width:100%;" name="fornecedor" id="fornecedor" required>
                                <option id="ativo-placeholder" selected disabled value="">-- Selecionar --</option>
                                <?php foreach($fornecedores as $fornecedor){ ?>
                                     <option value="<?php echo $fornecedor['fornecedor_cnpj'] ?>"><?php echo $fornecedor['fornecedor_nome'] ?></option>;
                                <?php } ?>
                            </select>
                        </div>
                        
                    </div>
                    
                    <br>
                    <hr style="height: 1px; background-color: #ccc; border: none;"><br>
                    <br>
                    
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="un_medida">Unidade de medida</label><br>
                            <input id="un_medida" name="un_medida" type="text" class="form-control" placeholder="Ex.: milímetros, centímetros, metros etc" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="comprimento">Comprimento</label><br>
                            <input id="comprimento" name="comprimento" type="number" class="form-control" placeholder="Ex.: 10" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="largura">Largura</label><br>
                            <input id="largura" name="largura" type="number" class="form-control" placeholder="Ex.: 10" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-3 form-group">
                            <label for="altura">Altura</label><br>
                            <input id="altura" name="altura" type="number" class="form-control" placeholder="Ex.: 10" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="un_peso">Unidade de peso</label><br>
                            <input id="un_peso" name="un_peso" type="text" class="form-control" placeholder="Ex.: milímetros, centímetros, metros etc" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="peso">Peso</label><br>
                            <input id="peso" name="peso" type="number" class="form-control" placeholder="Ex.: 10" required>
                        </div>
                    </div>
                    
                    <br>
                    <hr style="height: 1px; background-color: #ccc; border: none;">
                    <br>
                    
                    <div class="row">
                        <div class="col-md-3 form-group">
                            <label for="sku">SKU</label><br>
                            <input id="sku" name="sku" type="text" class="form-control" maxsize="64" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="ncm">NCM</label><br>
                            <input id="ncm" name="ncm" type="text" class="form-control" maxsize="12" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="cest">CEST</label><br>
                            <input id="cest" name="cest" type="text" class="form-control" maxsize="12" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="upc">UPC</label><br>
                            <input id="upc" name="upc" type="text" class="form-control" maxsize="12" required >
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-3 form-group">
                            <label for="ean">EAN</label><br>
                            <input id="ean" name="ean" type="text" class="form-control" maxsize="14" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="jan">JAN</label><br>
                            <input id="jan" name="jan" type="text" class="form-control" maxsize="13" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="isbn">ISBN</label><br>
                            <input id="isbn" name="isbn" type="text" class="form-control" maxsize="17" required>
                        </div>
                        <div class="col-md-3 form-group">
                            <label for="mpn">MPN</label><br>
                            <input id="mpn" name="mpn" type="text" class="form-control" maxsize="64" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 form-group">
                            <label for="detalhes">Detalhes</label><br>
                            <textarea id="detalhes" name="detalhes" type="text" class="form-control" style="resize:none;" rows="4" required></textarea>
                        </div>
                    </div>
                    
                    <!--
                    <div class="row">
                        <div class="col-md-6">
                            <div class="col-md-12">
                                <div class="ml-2 col-sm-6">
                                    <img src="
                                    <?php /* if(isset($_GET['edicao_id'])){
                                                echo base_url('uploads/' . $_GET['edicao_id'] . '_cnh.png');
                                            }else{
                                                echo base_url('resources/imgs/imgplaceholder.png');
                                            } ?>
                                    
                                    " id="cpf-preview" class="img-thumbnail" style="max-width:200px; height:auto;"/>
                                </div>
                                <div class="ml-2 col-sm-6">
                                    <div class="input-group my-3">
                                        <h4 style="width:100%">CNH</h4>
                                        <input type="text" class="form-control" placeholder="Selecione uma imagem" id="cnh-file" 
                                        value="<?php if(isset($_GET['edicao_id'])){ echo $_GET['edicao_id'] . '_id.png'; } ?>" disabled style="width: 100%"/>
                                        <div class="input-group-append">
                                            <input id="cnh-doc" type="file" name="cnh-doc" form="motoristaForm" class="file" accept="image/png" style="display:none;" 
                                            <?php if(isset($_GET['edicao_id'])){ echo "disabled" ; } */ ?> required />
                                            <button id="cnh-search" type="button" class="browse btn btn-primary" style="width:100%">Buscar...</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    -->
                    <!-- -->
                
                    <br><br>
                </div>
            
            </div>
            
            <br><br>
            
            <div class="row">
                <div class="col-md-12 text-center">
                    <a href="<?php echo base_url('produtos/listagem') ?>" class="btn btn-danger">&nbsp&nbspCancelar&nbsp&nbsp</a>
                    &nbsp&nbsp&nbsp&nbsp
                    <button type="submit" id="btn-save" class="btn btn-primary disabled-field" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white" disabled>&nbsp&nbspSalvar&nbsp&nbsp</button>
                    &nbsp&nbsp&nbsp&nbsp
                    <button type="button" id="btn-clear" class="btn btn-primary disabled-field" style="border: 1px solid #4ECDC4; background-color: #4ECDC4; color: white" disabled>&nbsp&nbspLimpar&nbsp&nbsp</button>
                </div>
            </div>
        
            <br><br>
        </form>
    </section>
</section>